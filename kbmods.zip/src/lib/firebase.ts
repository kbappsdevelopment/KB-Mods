import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import {
  getAuth,
  Auth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';

const firebaseConfig = {
  apiKey: "AIzaSyANCjblDmotshJhbieZDtt45hNgtY21CY4",
  authDomain: "kb-nova-kashyap.firebaseapp.com",
  databaseURL: "https://kb-nova-kashyap-default-rtdb.firebaseio.com",
  projectId: "kb-nova-kashyap",
  storageBucket: "kb-nova-kashyap.firebasestorage.app",
  messagingSenderId: "344066428648",
  appId: "1:344066428648:web:008d3f9dec3fbc3e15435d",
  measurementId: "G-WP5LLDTHTS"
};

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

try {
  if (!getApps().length) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApp();
  }
  db = getFirestore(app);
  auth = getAuth(app);
} catch (error) {
  console.warn("Firebase initialization notice:", error);
}

export {
  app,
  db,
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
  onAuthStateChanged
};
export type { User };

