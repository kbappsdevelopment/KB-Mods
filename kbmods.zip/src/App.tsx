import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { CategoryList } from './components/CategoryList';
import { AppCard } from './components/AppCard';
import { AppDetail } from './components/AppDetail';
import { DownloadModal } from './components/DownloadModal';
import { AdminPanel } from './components/AdminPanel';
import { SEOModal } from './components/SEOModal';
import { Footer } from './components/Footer';

import { INITIAL_APPS } from './data/initialApps';
import { INITIAL_CATEGORIES } from './data/categories';
import { AppItem, Category, Review, SEOMetadata, SiteStats } from './types';
import { Flame, Sparkles, Filter, Layers, ArrowUpDown, Check } from 'lucide-react';

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState(true);

  // Core Data State with LocalStorage Persistence
  const [apps, setApps] = useState<AppItem[]>(() => {
    const saved = localStorage.getItem('kbmods_apps');
    return saved ? JSON.parse(saved) : INITIAL_APPS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem('kbmods_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('kbmods_reviews');
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'rev-1',
            appId: 'subway-surfers-mod',
            userName: 'David K.',
            rating: 5,
            comment: 'Working perfectly! Unlimited keys and coins activated right away.',
            createdAt: '2026-08-10',
            verifiedDownload: true,
          },
          {
            id: 'rev-2',
            appId: 'spotify-premium-mod',
            userName: 'Sarah M.',
            rating: 5,
            comment: 'Zero ads and ultra high audio quality on my Android 14 phone!',
            createdAt: '2026-08-11',
            verifiedDownload: true,
          },
        ];
  });

  const [seoData, setSeoData] = useState<SEOMetadata>({
    title: 'KBMods - Download Safe Android MOD APKs & Premium Apps (kbmods.us.cc)',
    description: 'Premier APK directory for hacked games, modified apps, and premium unlocked tools. 100% virus scanned and fast direct downloads.',
    keywords: 'MOD APK, Hacked Games, Premium Unlocked, Android APK, KBMods, kbmods.us.cc',
    ogImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
    canonicalUrl: 'https://kbmods.us.cc',
    robotsTxt: `User-agent: *\nAllow: /\nSitemap: https://kbmods.us.cc/sitemap.xml`,
  });

  // Navigation State
  const [currentView, setCurrentView] = useState<'home' | 'detail'>('home');
  const [selectedApp, setSelectedApp] = useState<AppItem | null>(null);
  const [selectedCategorySlug, setSelectedCategorySlug] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'All' | 'MOD' | 'Pure APK' | 'Premium Unlocked'>('All');
  const [sortBy, setSortBy] = useState<'popular' | 'latest' | 'downloads' | 'rating'>('popular');

  // Modals state
  const [downloadingApp, setDownloadingApp] = useState<AppItem | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isSEOModalOpen, setIsSEOModalOpen] = useState(false);

  // Sync state to LocalStorage
  useEffect(() => {
    localStorage.setItem('kbmods_apps', JSON.stringify(apps));
  }, [apps]);

  useEffect(() => {
    localStorage.setItem('kbmods_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('kbmods_reviews', JSON.stringify(reviews));
  }, [reviews]);

  // Handle HTML document title and meta updates
  useEffect(() => {
    if (selectedApp) {
      document.title = `${selectedApp.name} (${selectedApp.version}) - Download MOD APK | KBMods`;
    } else if (selectedCategorySlug) {
      const catObj = categories.find((c) => c.slug === selectedCategorySlug);
      document.title = `${catObj ? catObj.name : 'Category'} MOD APKs - KBMods Directory`;
    } else {
      document.title = seoData.title;
    }
  }, [selectedApp, selectedCategorySlug, seoData, categories]);

  // Handle App Selection
  const handleSelectApp = (app: AppItem) => {
    setSelectedApp(app);
    setCurrentView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle Category Selection
  const handleSelectCategory = (slug: string | null) => {
    setSelectedCategorySlug(slug);
    setSelectedApp(null);
    setCurrentView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle Adding Review
  const handleAddReview = (appId: string, name: string, rating: number, comment: string) => {
    const newRev: Review = {
      id: `rev-${Date.now()}`,
      appId,
      userName: name,
      rating,
      comment,
      createdAt: new Date().toISOString().split('T')[0],
      verifiedDownload: true,
    };
    setReviews([newRev, ...reviews]);
  };

  // CRUD Handlers for Admin Panel
  const handleAddApp = (newApp: AppItem) => {
    setApps([newApp, ...apps]);
  };

  const handleUpdateApp = (updatedApp: AppItem) => {
    setApps(apps.map((a) => (a.id === updatedApp.id ? updatedApp : a)));
    if (selectedApp?.id === updatedApp.id) {
      setSelectedApp(updatedApp);
    }
  };

  const handleDeleteApp = (id: string) => {
    setApps(apps.filter((a) => a.id !== id));
    if (selectedApp?.id === id) {
      setSelectedApp(null);
      setCurrentView('home');
    }
  };

  const handleAddCategory = (newCat: Category) => {
    setCategories([...categories, newCat]);
  };

  const handleDeleteCategory = (id: string) => {
    setCategories(categories.filter((c) => c.id !== id));
  };

  const handleDeleteReview = (id: string) => {
    setReviews(reviews.filter((r) => r.id !== id));
  };

  const handleImportBackup = (imported: { apps: AppItem[]; categories: Category[] }) => {
    setApps(imported.apps);
    if (imported.categories) setCategories(imported.categories);
  };

  // Filtering Logic
  let filteredApps = apps.filter((app) => {
    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchesName = app.name.toLowerCase().includes(q);
      const matchesCategory = app.category.toLowerCase().includes(q);
      const matchesDeveloper = app.developer.toLowerCase().includes(q);
      const matchesMod = app.modFeatures.some((f) => f.toLowerCase().includes(q));
      if (!matchesName && !matchesCategory && !matchesDeveloper && !matchesMod) return false;
    }

    // Category Slug filter
    if (selectedCategorySlug) {
      const catObj = categories.find((c) => c.slug === selectedCategorySlug);
      if (catObj && app.category.toLowerCase() !== catObj.name.toLowerCase()) {
        return false;
      }
    }

    // Type filter (MOD vs Pure APK vs Premium Unlocked)
    if (filterType !== 'All' && app.type !== filterType) {
      return false;
    }

    return true;
  });

  // Sorting Logic
  filteredApps.sort((a, b) => {
    if (sortBy === 'popular') return b.downloadCount - a.downloadCount;
    if (sortBy === 'latest') return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
    if (sortBy === 'downloads') return b.downloadCount - a.downloadCount;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0;
  });

  const featuredApps = apps.filter((a) => a.isFeatured);
  const trendingApps = apps.filter((a) => a.isTrending);

  const siteStats: SiteStats = {
    totalApps: apps.length,
    totalDownloads: apps.reduce((acc, a) => acc + a.downloadCount, 0),
    totalReviews: reviews.length,
    dailyVisitors: 14250,
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} font-sans transition-colors duration-300`}>
      {/* Header Bar */}
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        apps={apps}
        categories={categories}
        onSelectApp={handleSelectApp}
        onSelectCategory={handleSelectCategory}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenSEOModal={() => setIsSEOModalOpen(true)}
        currentView={currentView}
        setCurrentView={setCurrentView}
      />

      {/* Main Content Area */}
      <main>
        {currentView === 'home' && (
          <div>
            {/* Hero Section */}
            {!selectedCategorySlug && !searchQuery && (
              <HeroSection
                onSearch={(q) => setSearchQuery(q)}
                onSelectTag={(tag) => setSearchQuery(tag)}
                featuredCount={featuredApps.length}
              />
            )}

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10">
              {/* Active Category Header Banner if selected */}
              {selectedCategorySlug && (
                <div className="bg-gradient-to-r from-blue-900/60 to-slate-900 border border-blue-500/30 p-6 rounded-3xl flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-cyan-400 font-mono uppercase tracking-wider">
                      Category Directory
                    </span>
                    <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">
                      {categories.find((c) => c.slug === selectedCategorySlug)?.name || 'Category'} MOD APKs
                    </h1>
                    <p className="text-xs text-slate-300 mt-1">
                      {categories.find((c) => c.slug === selectedCategorySlug)?.description}
                    </p>
                  </div>

                  <button
                    onClick={() => handleSelectCategory(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 rounded-xl border border-slate-700 shrink-0"
                  >
                    Clear Filter
                  </button>
                </div>
              )}

              {/* Filter & Sorting Controls */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-4 rounded-2xl">
                {/* Type Filter Pills */}
                <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
                  <span className="text-slate-400 mr-1 flex items-center gap-1">
                    <Filter className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Type:</span>
                  </span>
                  {(['All', 'MOD', 'Pure APK', 'Premium Unlocked'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setFilterType(t)}
                      className={`px-3 py-1.5 rounded-xl transition-colors ${
                        filterType === t
                          ? 'bg-cyan-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-800/80 text-slate-300 hover:text-white'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>

                {/* Sorting Select */}
                <div className="flex items-center gap-2 text-xs">
                  <span className="text-slate-400 flex items-center gap-1">
                    <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Sort By:</span>
                  </span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-slate-800 border border-slate-700 text-white text-xs rounded-xl px-3 py-1.5 focus:outline-none focus:border-cyan-400"
                  >
                    <option value="popular">Most Popular</option>
                    <option value="latest">Latest Updated</option>
                    <option value="downloads">Highest Downloads</option>
                    <option value="rating">Top Rated</option>
                  </select>
                </div>
              </div>

              {/* Featured Showcase Carousel Grid */}
              {!selectedCategorySlug && !searchQuery && featuredApps.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-amber-400" />
                      <span>Featured MOD Applications</span>
                    </h2>
                    <span className="text-xs text-slate-400 font-mono">Top Hand-Picked Releases</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {featuredApps.slice(0, 4).map((app) => (
                      <AppCard
                        key={app.id}
                        app={app}
                        onSelect={handleSelectApp}
                        onQuickDownload={(a) => setDownloadingApp(a)}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* All Apps Directory Grid */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
                    <Layers className="w-5 h-5 text-cyan-400" />
                    <span>
                      {selectedCategorySlug
                        ? `${categories.find((c) => c.slug === selectedCategorySlug)?.name} (${filteredApps.length})`
                        : searchQuery
                        ? `Search Results for "${searchQuery}" (${filteredApps.length})`
                        : `All Directory Apps (${filteredApps.length})`}
                    </span>
                  </h2>
                </div>

                {filteredApps.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {filteredApps.map((app) => (
                      <AppCard
                        key={app.id}
                        app={app}
                        onSelect={handleSelectApp}
                        onQuickDownload={(a) => setDownloadingApp(a)}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-3xl space-y-3">
                    <p className="text-base font-bold text-white">No apps found matching your query.</p>
                    <p className="text-xs text-slate-400">Try clearing your search query or switching category filters.</p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setFilterType('All');
                        setSelectedCategorySlug(null);
                      }}
                      className="px-4 py-2 bg-cyan-500 text-slate-950 font-bold text-xs rounded-xl"
                    >
                      Reset All Filters
                    </button>
                  </div>
                )}
              </div>

              {/* Popular Categories Grid Section */}
              {!selectedCategorySlug && !searchQuery && (
                <CategoryList
                  categories={categories}
                  selectedCategorySlug={selectedCategorySlug}
                  onSelectCategory={handleSelectCategory}
                />
              )}
            </div>
          </div>
        )}

        {/* App Detail View */}
        {currentView === 'detail' && selectedApp && (
          <AppDetail
            app={selectedApp}
            allApps={apps}
            reviews={reviews}
            onBack={() => {
              setSelectedApp(null);
              setCurrentView('home');
            }}
            onSelectApp={handleSelectApp}
            onOpenDownloadModal={(appToDl) => setDownloadingApp(appToDl)}
            onAddReview={handleAddReview}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        categories={categories}
        onSelectCategory={handleSelectCategory}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenSEOModal={() => setIsSEOModalOpen(true)}
      />

      {/* Direct Mirror Download Modal */}
      <DownloadModal
        app={downloadingApp}
        onClose={() => setDownloadingApp(null)}
        onDownloadStarted={(app) => {
          // Increment download counter
          setApps((prev) =>
            prev.map((a) => (a.id === app.id ? { ...a, downloadCount: a.downloadCount + 1 } : a))
          );
        }}
      />

      {/* Admin Control Panel Modal */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        apps={apps}
        categories={categories}
        reviews={reviews}
        seoData={seoData}
        stats={siteStats}
        onAddApp={handleAddApp}
        onUpdateApp={handleUpdateApp}
        onDeleteApp={handleDeleteApp}
        onAddCategory={handleAddCategory}
        onDeleteCategory={handleDeleteCategory}
        onDeleteReview={handleDeleteReview}
        onUpdateSEO={setSeoData}
        onImportBackup={handleImportBackup}
      />

      {/* SEO Inspector Modal */}
      <SEOModal
        isOpen={isSEOModalOpen}
        onClose={() => setIsSEOModalOpen(false)}
        seoData={seoData}
        apps={apps}
        selectedApp={selectedApp}
      />
    </div>
  );
}
