export type AppType = 'MOD' | 'Pure APK' | 'Premium Unlocked';

export interface Review {
  id: string;
  appId: string;
  userName: string;
  userAvatar?: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string; // ISO date
  likes?: number;
  verifiedDownload?: boolean;
}

export interface AppItem {
  id: string;
  name: string;
  packageName: string;
  category: string;
  version: string;
  appSize: string; // e.g. "145 MB"
  androidRequirement: string; // e.g. "Android 7.0+"
  developer: string;
  lastUpdated: string; // e.g. "2026-08-10"
  type: AppType;
  modFeatures: string[];
  iconUrl: string;
  bannerUrl?: string;
  screenshots: string[];
  description: string;
  changelog: string[];
  downloadUrl: string;
  fileSizeMb: number;
  rating: number; // e.g. 4.8
  reviewCount: number;
  downloadCount: number; // e.g. 1540000
  isFeatured?: boolean;
  isTrending?: boolean;
  isPopular?: boolean;
  sha256?: string;
  faqs?: { question: string; answer: string }[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  description: string;
  appCount: number;
  color: string;
}

export interface FilterOptions {
  searchQuery: string;
  category: string;
  type: 'All' | 'MOD' | 'Pure APK' | 'Premium Unlocked';
  sortBy: 'popular' | 'latest' | 'downloads' | 'rating';
  minAndroid?: string;
}

export interface SEOMetadata {
  title: string;
  description: string;
  keywords: string;
  ogImage: string;
  canonicalUrl: string;
  robotsTxt: string;
}

export interface SiteStats {
  totalApps: number;
  totalDownloads: number;
  totalReviews: number;
  dailyVisitors: number;
}
