import { Category } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'action-games',
    name: 'Action Games',
    slug: 'action-games',
    iconName: 'Swords',
    description: 'Thrill-packed action games, battle royales, and FPS mods with unlocked weapons and god mode.',
    appCount: 42,
    color: 'from-amber-500 to-red-600'
  },
  {
    id: 'racing-games',
    name: 'Racing Games',
    slug: 'racing-games',
    iconName: 'Car',
    description: 'High-speed racing simulators with all supercars unlocked, unlimited nitro, and money.',
    appCount: 35,
    color: 'from-blue-500 to-indigo-600'
  },
  {
    id: 'adventure-games',
    name: 'Adventure Games',
    slug: 'adventure-games',
    iconName: 'Compass',
    description: 'Immersive story-driven RPGs, open-world exploration, and survival mods.',
    appCount: 28,
    color: 'from-emerald-500 to-teal-700'
  },
  {
    id: 'sports-games',
    name: 'Sports Games',
    slug: 'sports-games',
    iconName: 'Trophy',
    description: 'Realistic football, basketball, and cricket simulators with unlimited coins and VIP passes.',
    appCount: 19,
    color: 'from-green-500 to-emerald-600'
  },
  {
    id: 'strategy-games',
    name: 'Strategy Games',
    slug: 'strategy-games',
    iconName: 'ShieldAlert',
    description: 'Base building, empire tactics, and tower defense games with infinite gems and resources.',
    appCount: 31,
    color: 'from-purple-500 to-indigo-700'
  },
  {
    id: 'simulation-games',
    name: 'Simulation Games',
    slug: 'simulation-games',
    iconName: 'Gamepad2',
    description: 'Life simulators, city builders, and flight simulators with maximum stats and money.',
    appCount: 24,
    color: 'from-cyan-500 to-blue-600'
  },
  {
    id: 'arcade-games',
    name: 'Arcade Games',
    slug: 'arcade-games',
    iconName: 'Joystick',
    description: 'Classic endless runners, casual jump-and-run, and retro arcade titles unlocked.',
    appCount: 48,
    color: 'from-pink-500 to-rose-600'
  },
  {
    id: 'educational-apps',
    name: 'Educational Apps',
    slug: 'educational-apps',
    iconName: 'GraduationCap',
    description: 'Language learning tools, STEM practice apps, and study guides with premium subscriptions unlocked.',
    appCount: 16,
    color: 'from-amber-400 to-orange-600'
  },
  {
    id: 'productivity-apps',
    name: 'Productivity Apps',
    slug: 'productivity-apps',
    iconName: 'Briefcase',
    description: 'Document scanners, note-taking suites, and office suites with full PRO licenses.',
    appCount: 22,
    color: 'from-sky-500 to-blue-700'
  },
  {
    id: 'social-apps',
    name: 'Social Apps',
    slug: 'social-apps',
    iconName: 'MessageSquare',
    description: 'Enhanced messaging, custom social networks with anti-delete features, and dark mode tweaks.',
    appCount: 18,
    color: 'from-violet-500 to-purple-600'
  },
  {
    id: 'entertainment-apps',
    name: 'Entertainment Apps',
    slug: 'entertainment-apps',
    iconName: 'Tv',
    description: 'Movie streaming, music players, and anime apps with ad-free VIP access.',
    appCount: 39,
    color: 'from-rose-500 to-red-700'
  },
  {
    id: 'tools-utilities',
    name: 'Tools & Utilities',
    slug: 'tools-utilities',
    iconName: 'Wrench',
    description: 'System boosters, file managers, VPNs, and VPN proxies with premium unlocked features.',
    appCount: 52,
    color: 'from-slate-600 to-zinc-800'
  }
];
