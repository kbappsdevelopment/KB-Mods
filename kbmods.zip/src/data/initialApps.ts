import { AppItem } from '../types';

export const INITIAL_APPS: AppItem[] = [
  {
    id: 'subway-surfers-mod',
    name: 'Subway Surfers MOD APK',
    packageName: 'com.kiloo.subwaysurf',
    category: 'Arcade Games',
    version: 'v3.25.1',
    appSize: '162 MB',
    androidRequirement: 'Android 5.0+',
    developer: 'SYBO Games',
    lastUpdated: '2026-08-10',
    type: 'MOD',
    modFeatures: [
      'Unlimited Coins & Keys',
      'All Characters & Boards Unlocked',
      'High Jump & Infinite Multiplier',
      'No Ads Experience',
      'Anti-Ban Security Protection'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Dash as fast as you can through subway tracks! Dodge oncoming trains with Jake, Tricky & Fresh in the world famous endless runner. The MOD APK gives you infinite keys and coins to unlock every character, outfit, and hoverboard instantly.',
    changelog: [
      'Added World Tour Tokyo event content',
      'New secret character: Akio with Cyberpunk outfit',
      'Improved anti-cheat bypass for online scoreboards',
      'Bug fixes and framerate stabilization on 120Hz screens'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/subway-surfers-v3.25.1-mod-kbmods.apk',
    fileSizeMb: 162,
    rating: 4.9,
    reviewCount: 14820,
    downloadCount: 3850000,
    isFeatured: true,
    isTrending: true,
    isPopular: true,
    sha256: '9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b',
    faqs: [
      { question: 'Is this Subway Surfers MOD safe to install?', answer: 'Yes, all files on KBMods are thoroughly verified with VirusTotal and Play Protect scanners before publishing.' },
      { question: 'Do I need to root my Android phone?', answer: 'No root required! Simply download the APK and tap install.' },
      { question: 'Will my high score connect to Facebook?', answer: 'Yes, social login works via web authentication without needing Google Play Services login.' }
    ]
  },
  {
    id: 'spotify-premium-mod',
    name: 'Spotify Premium MOD APK',
    packageName: 'com.spotify.music',
    category: 'Entertainment Apps',
    version: 'v8.9.72.583',
    appSize: '68 MB',
    androidRequirement: 'Android 6.0+',
    developer: 'Spotify AB',
    lastUpdated: '2026-08-11',
    type: 'Premium Unlocked',
    modFeatures: [
      'Spotify Premium Features Unlocked',
      'Unlimited Song Skips',
      'Ad-Free Uninterrupted Audio & Video',
      'High Quality 320kbps Audio Stream',
      'Extreme Bass Boost & Custom Equalizer Enabled'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1614680376593-902f749f7ba3?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Listen to millions of songs, podcasts, and audiobooks for free. This Spotify Premium Mod APK unlocks all paid features including unlimited skips, ad blocking, canvas videos, and loss-less sound quality.',
    changelog: [
      'Updated to latest base version v8.9.72',
      'Fixed lyric synchronisation for non-English songs',
      'Disabled unwanted telemetry and analytics tracking',
      'Enhanced dark AMOLED pitch black theme option'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/spotify-v8.9.72-premium-kbmods.apk',
    fileSizeMb: 68,
    rating: 4.8,
    reviewCount: 32900,
    downloadCount: 8900000,
    isFeatured: true,
    isTrending: true,
    isPopular: true,
    sha256: '4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d7c6b5a4f3e',
    faqs: [
      { question: 'Can I download songs offline with Spotify Mod?', answer: 'Offline downloading requires server-side DRM, but you can stream unlimited ad-free high quality audio on wifi or mobile data.' },
      { question: 'Should I create a secondary account?', answer: 'We always recommend using a dedicated free Spotify account when using modified client applications.' }
    ]
  },
  {
    id: 'gta-san-andreas-mod',
    name: 'GTA San Andreas MOD APK + OBB',
    packageName: 'com.rockstargames.gtasa',
    category: 'Action Games',
    version: 'v2.11.32',
    appSize: '2.4 GB',
    androidRequirement: 'Android 8.0+',
    developer: 'Rockstar Games',
    lastUpdated: '2026-08-08',
    type: 'MOD',
    modFeatures: [
      'Unlimited Money ($999,999,999)',
      'Cleo Cheat Menu Included',
      'Infinite Health & Armor',
      'All Vehicles & Weapons Unlocked',
      'Remastered 60FPS Graphic Patch'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Experience Carl Johnson’s journey across San Andreas to save his family and take control of the streets. This MOD features the full original game, Cleo script menu for spawning vehicles, weapons, and graphics enhancements.',
    changelog: [
      'Added Android 14 and 15 compatibility fix',
      'Integrated Cleo Touch menu with instant teleportation cheats',
      'Compressed OBB data for faster installation',
      'Fixed controller vibration bug'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/gta-sa-v2.11.32-cleo-mod-kbmods.apk',
    fileSizeMb: 2400,
    rating: 4.9,
    reviewCount: 29400,
    downloadCount: 5400000,
    isFeatured: true,
    isTrending: true,
    isPopular: true,
    sha256: '8e7d6c5b4a3f2e1d0c9b8a7f6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e7d'
  },
  {
    id: 'capcut-pro-mod',
    name: 'CapCut Pro MOD APK',
    packageName: 'com.lemon.lvoverseas',
    category: 'Tools & Utilities',
    version: 'v12.4.0',
    appSize: '115 MB',
    androidRequirement: 'Android 7.0+',
    developer: 'Bytedance Pte. Ltd.',
    lastUpdated: '2026-08-09',
    type: 'Premium Unlocked',
    modFeatures: [
      'Pro Subscription Features Unlocked',
      'Export in 4K 60FPS Without Watermark',
      'AI Body Effects & Smart Cutout Unlocked',
      'All VIP Filters, Fonts & Transitions',
      'No Ads & Fast Cloud Render Engine'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Create incredible videos with easy-to-use video editing tools, free music, AI auto-captions, and trending effects. CapCut Pro MOD removes watermarks and unlocks all premium assets.',
    changelog: [
      'Unlocked 2026 AI Voice Generator & Video Enhancer',
      'Fixed 4K export error on Mali GPU devices',
      'Removed forced login requirement for video rendering'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/capcut-v12.4.0-pro-kbmods.apk',
    fileSizeMb: 115,
    rating: 4.8,
    reviewCount: 21000,
    downloadCount: 6200000,
    isFeatured: true,
    isTrending: true,
    isPopular: true
  },
  {
    id: 'asphalt-9-legends-mod',
    name: 'Asphalt 9: Legends MOD APK',
    packageName: 'com.gameloft.anmp.asphalt9',
    category: 'Racing Games',
    version: 'v4.5.1',
    appSize: '2.1 GB',
    androidRequirement: 'Android 7.0+',
    developer: 'Gameloft SE',
    lastUpdated: '2026-08-05',
    type: 'MOD',
    modFeatures: [
      'Unlimited Nitro Refill',
      'Disable AI Opponents (Easy Win)',
      'Speed Hack Modifier',
      'Ghost Mode (No Crash Collisions)',
      'Unlocked VIP License'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Take the wheel of real hypercars from Ferrari, Porsche, Lamborghini, and W Motors. Race across jaw-dropping real-world locations with infinite nitro boost and auto-steering aids.',
    changelog: [
      'New supercar series: Bugatti Tourbillon',
      'Anti-ban code patch v4.5',
      'Fixed controller rumble feedback'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/asphalt9-v4.5.1-mod-kbmods.apk',
    fileSizeMb: 2100,
    rating: 4.7,
    reviewCount: 18500,
    downloadCount: 4100000,
    isFeatured: false,
    isTrending: true,
    isPopular: true
  },
  {
    id: 'minecraft-pe-mod',
    name: 'Minecraft Bedrock MOD APK',
    packageName: 'com.mojang.minecraftpe',
    category: 'Simulation Games',
    version: 'v1.21.20',
    appSize: '720 MB',
    androidRequirement: 'Android 8.0+',
    developer: 'Mojang Studios',
    lastUpdated: '2026-08-07',
    type: 'MOD',
    modFeatures: [
      'Full Game Unlocked (License Bypassed)',
      'Immortal God Mode',
      'One Hit Kill with Weapon',
      'All Premium Skins & Textures Unlocked',
      'Infinite Resource Stack'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1627856013091-fed6e4e30025?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Explore infinite worlds and build everything from the simplest of homes to the grandest of castles. Play in creative mode with unlimited resources or mine deep into the world in survival mode.',
    changelog: [
      'Tricky Trials update features: Breeze mob & Crafter block',
      'Fixed custom shaders loading crash',
      'Xbox Live sign-in support patch'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/minecraft-v1.21.20-mod-kbmods.apk',
    fileSizeMb: 720,
    rating: 4.9,
    reviewCount: 45200,
    downloadCount: 12400000,
    isFeatured: true,
    isTrending: true,
    isPopular: true
  },
  {
    id: 'clash-of-clans-mod',
    name: 'Clash of Clans Private Server MOD',
    packageName: 'com.supercell.clashofclans.mod',
    category: 'Strategy Games',
    version: 'v16.300.1',
    appSize: '340 MB',
    androidRequirement: 'Android 6.0+',
    developer: 'Supercell (Nulls Server)',
    lastUpdated: '2026-08-04',
    type: 'MOD',
    modFeatures: [
      'Unlimited Gems ($999,999,999)',
      'Unlimited Gold & Elixir',
      'Town Hall 16 Max Upgrades',
      'Custom Troops & Hero Skins Unlocked',
      'Dedicated Fast Private Server'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1563089145-599997674d42?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Join millions of players worldwide as you build your village, raise a clan, and compete in epic Clan Wars! This private server edition gives you infinite resources so you can upgrade Town Hall 16 instantly.',
    changelog: [
      'Added Root Rider troop & Spirit Fox hero pet',
      'Instant army training command added (/cut)',
      'Guild clan wars working smoothly'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/coc-v16.300.1-nulls-mod-kbmods.apk',
    fileSizeMb: 340,
    rating: 4.8,
    reviewCount: 38100,
    downloadCount: 7800000,
    isFeatured: true,
    isTrending: false,
    isPopular: true
  },
  {
    id: 'duolingo-plus-mod',
    name: 'Duolingo Super MOD APK',
    packageName: 'com.duolingo',
    category: 'Educational Apps',
    version: 'v5.148.4',
    appSize: '48 MB',
    androidRequirement: 'Android 7.0+',
    developer: 'Duolingo',
    lastUpdated: '2026-08-06',
    type: 'Premium Unlocked',
    modFeatures: [
      'Super Duolingo Features Unlocked',
      'Unlimited Hearts System',
      'Ad-Free Learning Path',
      'Mistakes Review & Mastery Quiz Unlocked',
      'Bonus Stories & offline lessons'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Learn Spanish, French, German, Japanese, English, and 40+ languages through bite-sized lessons. Super Duolingo MOD unlocks infinite hearts so you never lose progress while practicing.',
    changelog: [
      'Unlocked Chess & Math courses',
      'Bypassed heartbeat tracking',
      'Optimized lightweight APK size'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/duolingo-v5.148.4-super-kbmods.apk',
    fileSizeMb: 48,
    rating: 4.9,
    reviewCount: 16200,
    downloadCount: 3200000,
    isFeatured: false,
    isTrending: true,
    isPopular: false
  },
  {
    id: 'expressvpn-mod',
    name: 'ExpressVPN Premium MOD APK',
    packageName: 'com.expressvpn.vpn',
    category: 'Tools & Utilities',
    version: 'v11.82.0',
    appSize: '54 MB',
    androidRequirement: 'Android 6.0+',
    developer: 'ExpressVPN',
    lastUpdated: '2026-08-09',
    type: 'Premium Unlocked',
    modFeatures: [
      'Unlimited Free Trial Loop Mod',
      'Access 3,000+ VPN Servers in 105 Countries',
      'No Logs Policy & Lightway Protocol Enabled',
      'Unlimited Bandwidth & Auto Kill Switch',
      'Ad & Tracker Blocker Unlocked'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Secure your internet connection, bypass geo-restrictions, and keep your IP address private with one-tap VPN encryption. Features unlimited bandwidth across servers globally.',
    changelog: [
      'Automated email generator for 7-day trial bypass',
      'Added wireguard-based Lightway Turbo protocol',
      'Enhanced leak protection'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/expressvpn-v11.82.0-mod-kbmods.apk',
    fileSizeMb: 54,
    rating: 4.8,
    reviewCount: 27500,
    downloadCount: 5100000,
    isFeatured: true,
    isTrending: true,
    isPopular: true
  },
  {
    id: 'kinemaster-pro-mod',
    name: 'KineMaster Pro MOD APK',
    packageName: 'com.nexstreaming.app.kinemasterfree',
    category: 'Productivity Apps',
    version: 'v7.4.2',
    appSize: '95 MB',
    androidRequirement: 'Android 8.0+',
    developer: 'KineMaster Corporation',
    lastUpdated: '2026-08-03',
    type: 'Premium Unlocked',
    modFeatures: [
      'No Watermark on Exported Video',
      'All Asset Store Items Unlocked (Transitions, FX)',
      'Multi-Layer Chroma Key (Green Screen)',
      '4K 60FPS High Bitrate Export',
      'Ad-Free UI Interface'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'KineMaster makes video editing fun on your phone or tablet! Edit videos with transitions, keyframe animation, green screen effect, motion tracking, and export without watermarks.',
    changelog: [
      'New AI Magic Cutout background remover',
      'Fixed black screen preview on Android 14',
      'Speed ramp controls updated'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/kinemaster-v7.4.2-pro-kbmods.apk',
    fileSizeMb: 95,
    rating: 4.7,
    reviewCount: 19800,
    downloadCount: 4200000,
    isFeatured: false,
    isTrending: false,
    isPopular: true
  },
  {
    id: 'whatsapp-plus-apk',
    name: 'WhatsApp Plus Anti-Ban APK',
    packageName: 'com.whatsapp.plus',
    category: 'Social Apps',
    version: 'v18.20',
    appSize: '58 MB',
    androidRequirement: 'Android 5.0+',
    developer: 'Fouad Mods / KBMods Team',
    lastUpdated: '2026-08-10',
    type: 'MOD',
    modFeatures: [
      'Anti-Delete Messages & Statuses',
      'Freeze Last Seen Online Status',
      'Hide Blue Ticks & Typing Indicator',
      'Send HD Files Up To 1GB',
      'Custom Themes Engine & Font Style'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'WhatsApp Plus is a customized version of standard WhatsApp with advanced privacy options, custom theme support, anti-delete status viewing, and higher file transfer limits.',
    changelog: [
      'Updated base code to 2.24.16.76',
      'Enhanced V18 Anti-Ban shield against account suspensions',
      'Added AI Sticker Generator shortcut'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/whatsapp-plus-v18.20-antiban-kbmods.apk',
    fileSizeMb: 58,
    rating: 4.9,
    reviewCount: 52100,
    downloadCount: 15100000,
    isFeatured: true,
    isTrending: true,
    isPopular: true
  },
  {
    id: 'shadow-fight-2-mod',
    name: 'Shadow Fight 2 Special Edition MOD',
    packageName: 'com.nekki.shadowfight2',
    category: 'Action Games',
    version: 'v2.35.0',
    appSize: '142 MB',
    androidRequirement: 'Android 6.0+',
    developer: 'NEKKI',
    lastUpdated: '2026-08-01',
    type: 'MOD',
    modFeatures: [
      'Unlimited Gems & Coins',
      'Max Level 52 Unlocked',
      'All Weapons, Armor & Helmets Unlocked',
      'Infinite Energy System',
      'Enchantment Orbs Unlocked'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Nail-biting fight animation mixing martial arts and shadows. Journey through 7 demon gates and fight Titan with mythic magic spells and weapons.',
    changelog: [
      'Special Edition story chapter completely unlocked',
      'Fixed titan battle phase transition freeze',
      'HD graphics filter added'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/shadow-fight-2-v2.35.0-mod-kbmods.apk',
    fileSizeMb: 142,
    rating: 4.8,
    reviewCount: 14200,
    downloadCount: 2900000,
    isFeatured: false,
    isTrending: false,
    isPopular: true
  },
  {
    id: 'dream-league-soccer-mod',
    name: 'Dream League Soccer 2026 MOD APK',
    packageName: 'com.firsttouchgames.dls7',
    category: 'Sports Games',
    version: 'v11.210',
    appSize: '560 MB',
    androidRequirement: 'Android 7.0+',
    developer: 'First Touch Games Ltd.',
    lastUpdated: '2026-08-08',
    type: 'MOD',
    modFeatures: [
      'Unlimited Coins & Gems',
      'All Players Unlocked (Legendary 100 Overall)',
      'Disable AI Opponent Movement',
      'Custom Kits & Logos Loaded',
      'Full Stadium Capacity Maxed'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'DLS 2026 puts you in the heart of the soccer action with a fresh look and brand new features! Build your dream team from over 4,000 FIFPRO licensed players and take to the field against world football clubs.',
    changelog: [
      'Updated 2026 summer transfer squad rosters',
      'New motion-captured 3D player animations',
      'Infinite coins patch included'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/dls2026-v11.210-mod-kbmods.apk',
    fileSizeMb: 560,
    rating: 4.8,
    reviewCount: 22100,
    downloadCount: 4800000,
    isFeatured: true,
    isTrending: true,
    isPopular: true
  },
  {
    id: 'picsart-gold-mod',
    name: 'PicsArt Gold MOD APK',
    packageName: 'com.picsart.studio',
    category: 'Tools & Utilities',
    version: 'v25.1.2',
    appSize: '78 MB',
    androidRequirement: 'Android 6.0+',
    developer: 'PicsArt Inc.',
    lastUpdated: '2026-08-02',
    type: 'Premium Unlocked',
    modFeatures: [
      'PicsArt Gold Subscription Unlocked',
      'Ad-Free Photo & Video Editing',
      'AI Background Remover & Avatar Generator',
      'Millions of Premium Stickers & Fonts',
      'No Watermark HD Exports'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1542744094-3a31b272c490?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1542744094-3a31b272c490?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1542744094-3a31b272c490?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Join the PicsArt community of over 150 million creators around the world. With PicsArt AI photo and video editor, bring your creativity to life with full access to Gold filters and collage makers.',
    changelog: [
      'Unlocked AI Style Transfer tool',
      'Fixed HD saving crash',
      'Bypassed account subscription check'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/picsart-v25.1.2-gold-kbmods.apk',
    fileSizeMb: 78,
    rating: 4.7,
    reviewCount: 17400,
    downloadCount: 3900000,
    isFeatured: false,
    isTrending: false,
    isPopular: true
  },
  {
    id: 'hills-of-steel-mod',
    name: 'Hills of Steel MOD APK',
    packageName: 'com.superplusgames.hillsofsteel',
    category: 'Action Games',
    version: 'v6.2.0',
    appSize: '110 MB',
    androidRequirement: 'Android 5.0+',
    developer: 'Superplus Games',
    lastUpdated: '2026-07-29',
    type: 'MOD',
    modFeatures: [
      'Unlimited Money & Gems',
      'All Tanks & Weapons Unlocked',
      'Infinite Booster Boost',
      'VIP Pass Activated',
      'No Ads'
    ],
    iconUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=256&q=80',
    bannerUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=1200&q=80',
    screenshots: [
      'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Hills of Steel is probably the most addictive physics-based tank action game! Race through hills and crush your enemies with steel. Unlock all sci-fi tanks and hover vehicles.',
    changelog: [
      'New Titan Mech tank added',
      'Fixed coin multiplication glitch',
      '60fps physics patch'
    ],
    downloadUrl: 'https://kbmods.us.cc/downloads/hills-of-steel-v6.2.0-mod-kbmods.apk',
    fileSizeMb: 110,
    rating: 4.6,
    reviewCount: 8900,
    downloadCount: 1800000,
    isFeatured: false,
    isTrending: false,
    isPopular: false
  }
];
