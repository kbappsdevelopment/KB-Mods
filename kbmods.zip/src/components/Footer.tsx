import React from 'react';
import { Smartphone, ShieldCheck, Sparkles, Lock, ArrowUp } from 'lucide-react';
import { Category } from '../types';

interface FooterProps {
  categories: Category[];
  onSelectCategory: (slug: string | null) => void;
  onOpenAdmin: () => void;
  onOpenSEOModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  categories,
  onSelectCategory,
  onOpenAdmin,
  onOpenSEOModal,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs mt-16 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Column 1: Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => onSelectCategory(null)}>
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white">
                <Smartphone className="w-4 h-4" />
              </div>
              <span className="text-lg font-black text-white font-mono">
                KB<span className="text-cyan-400">Mods</span>
              </span>
            </div>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              kbmods.us.cc is the premier destination for verified Android MOD APKs, hacked games, and premium unlocked tools. All files are 100% virus scanned.
            </p>
            <div className="flex items-center gap-2 pt-1 text-emerald-400 text-[11px] font-bold">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Scanned with Play Protect & VirusTotal</span>
            </div>
          </div>

          {/* Column 2: Popular Categories */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Popular Categories</h4>
            <ul className="space-y-1.5 text-[11px]">
              {categories.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => onSelectCategory(cat.slug)}
                    className="hover:text-cyan-400 transition-colors"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: More Categories */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Directory Links</h4>
            <ul className="space-y-1.5 text-[11px]">
              {categories.slice(6, 12).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => onSelectCategory(cat.slug)}
                    className="hover:text-cyan-400 transition-colors"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Quick Tools */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">SEO & Admin Tools</h4>
            <div className="space-y-2">
              <button
                onClick={onOpenSEOModal}
                className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 text-left text-xs font-bold text-purple-300 flex items-center justify-between"
              >
                <span>Inspect SEO & Sitemap</span>
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              </button>

              <button
                onClick={onOpenAdmin}
                className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 rounded-xl border border-slate-800 text-left text-xs font-bold text-cyan-300 flex items-center justify-between"
              >
                <span>Admin Login Portal</span>
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
              </button>
            </div>
          </div>
        </div>

        {/* Disclaimer Notice */}
        <div className="p-4 bg-slate-900/60 rounded-2xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
          <p className="font-bold text-slate-300">Disclaimer & Copyright Notice:</p>
          <p>
            KBMods (kbmods.us.cc) is an educational Android APK & MOD directory. All trademarks, app icons, and logos belong to their respective developers and publishers. If you are a copyright holder and wish to submit a DMCA removal request, please contact our administrative team via the portal.
          </p>
        </div>

        {/* Bottom copyright */}
        <div className="pt-4 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© 2026 KBMods (kbmods.us.cc). All rights reserved.</p>
          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
