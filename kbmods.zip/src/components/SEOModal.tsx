import React, { useState } from 'react';
import { X, Sparkles, Code2, Globe, FileCode, Check, Copy, Download, ExternalLink } from 'lucide-react';
import { AppItem, SEOMetadata } from '../types';

interface SEOModalProps {
  isOpen: boolean;
  onClose: () => void;
  seoData: SEOMetadata;
  apps: AppItem[];
  selectedApp?: AppItem | null;
}

export const SEOModal: React.FC<SEOModalProps> = ({
  isOpen,
  onClose,
  seoData,
  apps,
  selectedApp,
}) => {
  const [activeTab, setActiveTab] = useState<'meta' | 'schema' | 'sitemap' | 'robots'>('meta');
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  const currentApp = selectedApp || apps[0];
  const pageTitle = currentApp
    ? `${currentApp.name} (${currentApp.version}) - Download MOD APK | KBMods`
    : seoData.title;
  const pageDesc = currentApp
    ? `Download ${currentApp.name} ${currentApp.version} MOD APK for Android (${currentApp.appSize}). ${currentApp.modFeatures.slice(0, 2).join(', ')}. 100% Virus Free on kbmods.us.cc.`
    : seoData.description;
  const canonicalUrl = currentApp ? `https://kbmods.us.cc/app/${currentApp.id}` : 'https://kbmods.us.cc';

  // Generate JSON-LD Schema
  const jsonLdSchema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": currentApp?.name || "KBMods Directory",
    "operatingSystem": "ANDROID",
    "applicationCategory": currentApp?.category || "GameApplication",
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": currentApp?.rating || "4.8",
      "ratingCount": currentApp?.reviewCount || "14820"
    },
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "softwareVersion": currentApp?.version || "v3.25.1",
    "fileSize": currentApp?.appSize || "162 MB",
    "downloadUrl": canonicalUrl
  };

  // Generate XML Sitemap
  const xmlSitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://kbmods.us.cc/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
${apps
  .map(
    (app) => `  <url>
    <loc>https://kbmods.us.cc/app/${app.id}</loc>
    <lastmod>${app.lastUpdated}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`
  )
  .join('\n')}
</urlset>`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const downloadSitemapFile = () => {
    const dataStr = "data:text/xml;charset=utf-8," + encodeURIComponent(xmlSitemap);
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = 'sitemap.xml';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-white my-8">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <h3 className="text-sm font-extrabold text-white">KBMods Dynamic SEO & Schema Engine</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2 overflow-x-auto text-xs font-bold">
          <button
            onClick={() => setActiveTab('meta')}
            className={`px-3 py-1.5 rounded-xl transition-colors ${
              activeTab === 'meta' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Meta & OpenGraph
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`px-3 py-1.5 rounded-xl transition-colors ${
              activeTab === 'schema' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            JSON-LD Schema
          </button>
          <button
            onClick={() => setActiveTab('sitemap')}
            className={`px-3 py-1.5 rounded-xl transition-colors ${
              activeTab === 'sitemap' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            XML Sitemap ({apps.length + 1} URLs)
          </button>
          <button
            onClick={() => setActiveTab('robots')}
            className={`px-3 py-1.5 rounded-xl transition-colors ${
              activeTab === 'robots' ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Robots.txt
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6 max-h-[65vh] overflow-y-auto space-y-4">
          {activeTab === 'meta' && (
            <div className="space-y-4 text-xs">
              {/* Google Search Result Preview */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Google Search Snippet Preview
                </h4>
                <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-1">
                  <p className="text-[11px] text-emerald-400 font-mono flex items-center gap-1">
                    <Globe className="w-3 h-3" />
                    <span>{canonicalUrl}</span>
                  </p>
                  <h3 className="text-base font-bold text-blue-400 hover:underline cursor-pointer">{pageTitle}</h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{pageDesc}</p>
                </div>
              </div>

              {/* Open Graph Tags */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Generated OpenGraph & Twitter Cards</h4>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] space-y-1 text-slate-300 overflow-x-auto">
                  <p className="text-purple-400">&lt;meta property="og:title" content="{pageTitle}" /&gt;</p>
                  <p className="text-purple-400">&lt;meta property="og:description" content="{pageDesc}" /&gt;</p>
                  <p className="text-purple-400">&lt;meta property="og:url" content="{canonicalUrl}" /&gt;</p>
                  <p className="text-purple-400">&lt;meta property="og:image" content="{currentApp?.iconUrl || seoData.ogImage}" /&gt;</p>
                  <p className="text-purple-400">&lt;meta name="twitter:card" content="summary_large_image" /&gt;</p>
                  <p className="text-purple-400">&lt;link rel="canonical" href="{canonicalUrl}" /&gt;</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'schema' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Schema.org SoftwareApplication JSON-LD
                </h4>
                <button
                  onClick={() => copyToClipboard(JSON.stringify(jsonLdSchema, null, 2))}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs rounded-lg flex items-center gap-1 font-mono"
                >
                  {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCode ? 'Copied' : 'Copy JSON'}</span>
                </button>
              </div>
              <pre className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-[11px] font-mono text-cyan-300 overflow-x-auto">
                {JSON.stringify(jsonLdSchema, null, 2)}
              </pre>
            </div>
          )}

          {activeTab === 'sitemap' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Dynamic XML Sitemap</h4>
                <div className="flex gap-2">
                  <button
                    onClick={() => copyToClipboard(xmlSitemap)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs rounded-lg flex items-center gap-1 font-mono"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy XML</span>
                  </button>
                  <button
                    onClick={downloadSitemapFile}
                    className="px-2.5 py-1 bg-purple-600 hover:bg-purple-500 text-white text-xs rounded-lg flex items-center gap-1 font-bold"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download sitemap.xml</span>
                  </button>
                </div>
              </div>
              <pre className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-[11px] font-mono text-emerald-400 overflow-x-auto max-h-80">
                {xmlSitemap}
              </pre>
            </div>
          )}

          {activeTab === 'robots' && (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Robots.txt Output</h4>
              <pre className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-[11px] font-mono text-slate-300 whitespace-pre-wrap">
                {seoData.robotsTxt}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
