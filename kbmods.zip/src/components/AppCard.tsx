import React from 'react';
import { Download, Star, Shield, ArrowDownToLine, Sparkles } from 'lucide-react';
import { AppItem } from '../types';

interface AppCardProps {
  app: AppItem;
  onSelect: (app: AppItem) => void;
  onQuickDownload?: (app: AppItem) => void;
  layout?: 'grid' | 'compact';
}

export const AppCard: React.FC<AppCardProps> = ({
  app,
  onSelect,
  onQuickDownload,
  layout = 'grid',
}) => {
  const formatDownloads = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return `${num}`;
  };

  if (layout === 'compact') {
    return (
      <div
        onClick={() => onSelect(app)}
        className="group relative bg-slate-800/60 dark:bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 hover:border-cyan-500/50 rounded-2xl p-3 flex items-center gap-3 cursor-pointer transition-all duration-200 shadow-md hover:shadow-cyan-500/10"
      >
        <img
          src={app.iconUrl}
          alt={app.name}
          className="w-12 h-12 rounded-xl object-cover bg-slate-950 shrink-0 border border-slate-700/80 group-hover:scale-105 transition-transform"
          loading="lazy"
        />

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-white truncate group-hover:text-cyan-400 transition-colors">
              {app.name}
            </h3>
          </div>
          <p className="text-xs text-slate-400 truncate mt-0.5">
            {app.category} • {app.version}
          </p>

          <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
            <span className="flex items-center text-amber-400 font-semibold">
              <Star className="w-3 h-3 fill-amber-400 mr-0.5" />
              {app.rating.toFixed(1)}
            </span>
            <span>•</span>
            <span className="text-slate-300 font-mono">{app.appSize}</span>
          </div>
        </div>

        <div className="shrink-0 flex flex-col items-end gap-1">
          <span
            className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
              app.type === 'MOD'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
            }`}
          >
            {app.type}
          </span>
          <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
            <ArrowDownToLine className="w-3 h-3 text-cyan-400" />
            {formatDownloads(app.downloadCount)}
          </span>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={() => onSelect(app)}
      className="group relative bg-slate-800/80 dark:bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/60 rounded-2xl p-4 flex flex-col justify-between cursor-pointer transition-all duration-300 shadow-lg hover:shadow-cyan-500/10 hover:-translate-y-1"
    >
      <div>
        {/* Top Badges */}
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="relative">
            <img
              src={app.iconUrl}
              alt={app.name}
              className="w-16 h-16 rounded-2xl object-cover bg-slate-950 border border-slate-700 shadow-md group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
            {app.isFeatured && (
              <span className="absolute -top-1 -right-1 bg-gradient-to-r from-amber-500 to-orange-500 text-white p-1 rounded-full shadow-lg" title="Featured App">
                <Sparkles className="w-3 h-3" />
              </span>
            )}
          </div>

          <div className="flex flex-col items-end gap-1.5">
            <span
              className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                app.type === 'MOD'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
              }`}
            >
              {app.type}
            </span>
            <span className="text-[11px] text-slate-400 font-mono bg-slate-950/60 px-2 py-0.5 rounded-md border border-slate-800">
              {app.appSize}
            </span>
          </div>
        </div>

        {/* Title and Info */}
        <h3 className="text-base font-bold text-white group-hover:text-cyan-400 transition-colors line-clamp-1 mb-1">
          {app.name}
        </h3>

        <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
          <span>{app.developer}</span>
          <span>•</span>
          <span className="text-cyan-400/90 font-medium">{app.version}</span>
        </div>

        {/* MOD Highlight Feature Pill */}
        {app.modFeatures && app.modFeatures.length > 0 && (
          <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-2 mb-3">
            <p className="text-[11px] text-amber-300 font-medium line-clamp-1 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
              {app.modFeatures[0]}
            </p>
          </div>
        )}
      </div>

      {/* Footer Info & Download Button */}
      <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between gap-2">
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center text-amber-400 font-bold">
            <Star className="w-3.5 h-3.5 fill-amber-400 mr-1" />
            {app.rating.toFixed(1)}
          </div>
          <div className="text-slate-400 text-[11px] flex items-center gap-1 font-mono">
            <Download className="w-3 h-3 text-cyan-400" />
            {formatDownloads(app.downloadCount)}
          </div>
        </div>

        <button
          onClick={(e) => {
            e.stopPropagation();
            if (onQuickDownload) {
              onQuickDownload(app);
            } else {
              onSelect(app);
            }
          }}
          className="bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white font-bold text-xs px-3 py-1.5 rounded-xl border border-blue-500/40 hover:border-transparent transition-all flex items-center gap-1"
        >
          <span>Get</span>
          <ArrowDownToLine className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
