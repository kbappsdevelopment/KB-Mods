import React, { useState } from 'react';
import { Search, ShieldCheck, Download, Zap, Sparkles, CheckCircle2 } from 'lucide-react';
import { AppItem } from '../types';

interface HeroSectionProps {
  onSearch: (query: string) => void;
  onSelectTag: (tag: string) => void;
  featuredCount: number;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSearch,
  onSelectTag,
  featuredCount,
}) => {
  const [inputVal, setInputVal] = useState('');

  const quickTags = [
    'Subway Surfers MOD',
    'Spotify Premium',
    'GTA San Andreas',
    'CapCut Pro',
    'WhatsApp Plus',
    'Minecraft PE',
    'Asphalt 9',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      onSearch(inputVal);
    }
  };

  return (
    <div className="relative overflow-hidden bg-slate-900 border-b border-slate-800 text-white pt-10 pb-12 sm:pt-16 sm:pb-20">
      {/* Glow Effects Background */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full pointer-events-none opacity-30">
        <div className="absolute top-[-10%] left-[20%] w-96 h-96 bg-blue-600 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[20%] w-96 h-96 bg-cyan-500 rounded-full blur-[120px]" />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-6">
        {/* Top Tag Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-800/80 border border-slate-700/80 text-cyan-300 text-xs font-semibold shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>kbmods.us.cc — Premier Android MOD Directory</span>
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
        </div>

        {/* Main Heading */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
          Download Safe <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400">MOD APKs</span> & Premium Games
        </h1>

        <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-300 font-normal leading-relaxed">
          Access thousands of verified Android apps, hacked games, and premium unlocked tools. Instant high-speed downloads scanned for malware with VirusTotal.
        </p>

        {/* Search Bar Input */}
        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto relative group">
          <div className="relative flex items-center bg-slate-950/90 border-2 border-slate-700 focus-within:border-cyan-400 rounded-2xl p-2 shadow-2xl transition-all">
            <Search className="w-5 h-5 text-slate-400 ml-3 shrink-0" />
            <input
              type="text"
              value={inputVal}
              onChange={(e) => {
                setInputVal(e.target.value);
                onSearch(e.target.value);
              }}
              placeholder="Search by app name, package name, or MOD feature..."
              className="w-full bg-transparent border-0 px-3 py-2 text-sm text-white placeholder-slate-400 focus:outline-none focus:ring-0"
            />
            <button
              type="submit"
              className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs sm:text-sm px-5 py-3 rounded-xl transition-all flex items-center gap-1.5 shrink-0 shadow-lg shadow-cyan-500/25"
            >
              <span>Search</span>
            </button>
          </div>
        </form>

        {/* Quick Search Tags */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-2 text-xs">
          <span className="text-slate-400 font-semibold uppercase text-[11px] tracking-wider">Popular:</span>
          {quickTags.map((tag) => (
            <button
              key={tag}
              onClick={() => {
                setInputVal(tag);
                onSelectTag(tag);
              }}
              className="px-3 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full border border-slate-700/60 transition-colors"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="pt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto text-left">
          <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-800 flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">100% Virus Free</h4>
              <p className="text-[10px] text-slate-400">Play Protect Scanned</p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-800 flex items-center gap-3">
            <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Ultra Fast Speed</h4>
              <p className="text-[10px] text-slate-400">Direct CDN Servers</p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-800 flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">No Root Needed</h4>
              <p className="text-[10px] text-slate-400">Standard APK Install</p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-800 flex items-center gap-3">
            <div className="p-2 bg-purple-500/10 text-purple-400 rounded-lg">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">10,000+ Files</h4>
              <p className="text-[10px] text-slate-400">Daily Updates</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
