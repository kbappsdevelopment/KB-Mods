import React from 'react';
import {
  Swords,
  Car,
  Compass,
  Trophy,
  ShieldAlert,
  Gamepad2,
  Joystick,
  GraduationCap,
  Briefcase,
  MessageSquare,
  Tv,
  Wrench,
  Grid
} from 'lucide-react';
import { Category } from '../types';

interface CategoryListProps {
  categories: Category[];
  selectedCategorySlug: string | null;
  onSelectCategory: (slug: string | null) => void;
}

export const CategoryList: React.FC<CategoryListProps> = ({
  categories,
  selectedCategorySlug,
  onSelectCategory,
}) => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Swords': return <Swords className="w-6 h-6" />;
      case 'Car': return <Car className="w-6 h-6" />;
      case 'Compass': return <Compass className="w-6 h-6" />;
      case 'Trophy': return <Trophy className="w-6 h-6" />;
      case 'ShieldAlert': return <ShieldAlert className="w-6 h-6" />;
      case 'Gamepad2': return <Gamepad2 className="w-6 h-6" />;
      case 'Joystick': return <Joystick className="w-6 h-6" />;
      case 'GraduationCap': return <GraduationCap className="w-6 h-6" />;
      case 'Briefcase': return <Briefcase className="w-6 h-6" />;
      case 'MessageSquare': return <MessageSquare className="w-6 h-6" />;
      case 'Tv': return <Tv className="w-6 h-6" />;
      case 'Wrench': return <Wrench className="w-6 h-6" />;
      default: return <Grid className="w-6 h-6" />;
    }
  };

  return (
    <div className="py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <Grid className="w-6 h-6 text-cyan-400" />
            <span>Popular Categories</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Browse through 12 specialized Android APK & MOD categories
          </p>
        </div>

        {selectedCategorySlug && (
          <button
            onClick={() => onSelectCategory(null)}
            className="text-xs font-bold text-cyan-400 hover:text-cyan-300 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700"
          >
            Show All
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {categories.map((cat) => {
          const isSelected = selectedCategorySlug === cat.slug;
          return (
            <div
              key={cat.id}
              onClick={() => onSelectCategory(isSelected ? null : cat.slug)}
              className={`group relative rounded-2xl p-4 border cursor-pointer transition-all duration-300 overflow-hidden ${
                isSelected
                  ? 'bg-slate-800 border-cyan-400 shadow-xl shadow-cyan-500/10 ring-2 ring-cyan-400/30'
                  : 'bg-slate-800/60 dark:bg-slate-900/80 hover:bg-slate-800 border-slate-700/80 hover:border-slate-600'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div
                  className={`p-3 rounded-xl bg-gradient-to-br ${cat.color} text-white shadow-md group-hover:scale-110 transition-transform`}
                >
                  {getCategoryIcon(cat.iconName)}
                </div>

                <span className="text-[11px] font-bold text-slate-300 bg-slate-950/60 px-2 py-0.5 rounded-full border border-slate-800 font-mono">
                  {cat.appCount}+ Apps
                </span>
              </div>

              <h3 className="text-sm font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                {cat.name}
              </h3>
              <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                {cat.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
