import React, { useState } from 'react';
import {
  ShieldCheck,
  Download,
  Star,
  Calendar,
  Smartphone,
  Info,
  CheckCircle2,
  ChevronRight,
  HelpCircle,
  MessageSquare,
  Sparkles,
  ArrowLeft,
  Share2,
  Copy,
  Check,
  Maximize2,
  X,
  ThumbsUp,
  FileText,
  Clock,
  Layers,
  Flame
} from 'lucide-react';
import { AppItem, Review } from '../types';
import { AppCard } from './AppCard';

interface AppDetailProps {
  app: AppItem;
  allApps: AppItem[];
  reviews: Review[];
  onBack: () => void;
  onSelectApp: (app: AppItem) => void;
  onOpenDownloadModal: (app: AppItem) => void;
  onAddReview: (appId: string, name: string, rating: number, comment: string) => void;
}

export const AppDetail: React.FC<AppDetailProps> = ({
  app,
  allApps,
  reviews,
  onBack,
  onSelectApp,
  onOpenDownloadModal,
  onAddReview,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'mod' | 'install' | 'reviews' | 'faq'>('overview');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Review Form state
  const [reviewerName, setReviewerName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const appReviews = reviews.filter((r) => r.appId === app.id);
  const relatedApps = allApps
    .filter((a) => a.id !== app.id && (a.category === app.category || a.type === app.type))
    .slice(0, 4);

  const handleShare = () => {
    navigator.clipboard.writeText(`https://kbmods.us.cc/app/${app.id}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewerName.trim() || !reviewComment.trim()) return;

    onAddReview(app.id, reviewerName.trim(), reviewRating, reviewComment.trim());
    setReviewerName('');
    setReviewComment('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn text-slate-100">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-xs text-slate-400 overflow-x-auto py-1 font-mono">
        <button onClick={onBack} className="hover:text-cyan-400 flex items-center gap-1 transition-colors">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Home</span>
        </button>
        <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />
        <span className="text-slate-400">{app.category}</span>
        <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />
        <span className="text-cyan-400 font-bold truncate">{app.name}</span>
      </div>

      {/* Main Hero Card Header */}
      <div className="relative bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start sm:items-center gap-5">
            <img
              src={app.iconUrl}
              alt={app.name}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover bg-slate-950 border-2 border-slate-700 shadow-xl shrink-0"
            />
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider">
                  {app.type}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Verified Safe
                </span>
                <span className="text-xs text-slate-400 font-mono">{app.version}</span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">{app.name}</h1>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
                <span className="flex items-center text-amber-400 font-bold">
                  <Star className="w-4 h-4 fill-amber-400 mr-1" />
                  {app.rating.toFixed(1)} ({app.reviewCount.toLocaleString()} reviews)
                </span>
                <span>•</span>
                <span>Developer: <strong className="text-slate-200">{app.developer}</strong></span>
                <span>•</span>
                <span>Updated: <strong className="text-slate-200">{app.lastUpdated}</strong></span>
              </div>
            </div>
          </div>

          {/* Download Action Box */}
          <div className="w-full md:w-auto shrink-0 flex flex-col sm:flex-row md:flex-col gap-3">
            <button
              onClick={() => onOpenDownloadModal(app)}
              className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-extrabold text-base rounded-2xl shadow-xl shadow-cyan-500/20 transition-all flex items-center justify-center gap-3 transform hover:-translate-y-0.5 active:scale-95"
            >
              <Download className="w-5 h-5 animate-bounce" />
              <span>Download APK ({app.appSize})</span>
            </button>

            <button
              onClick={handleShare}
              className="w-full sm:w-auto px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold border border-slate-700 transition-colors flex items-center justify-center gap-2"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              <span>{copiedLink ? 'Link Copied!' : 'Share App'}</span>
            </button>
          </div>
        </div>

        {/* Quick Specs Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 pt-6 border-t border-slate-800 text-xs">
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">File Size</p>
            <p className="text-sm font-extrabold text-white mt-0.5 font-mono">{app.appSize}</p>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Requires Android</p>
            <p className="text-sm font-extrabold text-white mt-0.5 font-mono">{app.androidRequirement}</p>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Package Name</p>
            <p className="text-xs font-bold text-cyan-400 mt-1 font-mono truncate">{app.packageName}</p>
          </div>
          <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800">
            <p className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Downloads</p>
            <p className="text-sm font-extrabold text-white mt-0.5 font-mono">{app.downloadCount.toLocaleString()}+</p>
          </div>
        </div>
      </div>

      {/* MOD Features Highlight Banner */}
      {app.modFeatures && app.modFeatures.length > 0 && (
        <div className="bg-gradient-to-r from-amber-950/40 via-amber-900/20 to-slate-900 border border-amber-500/30 rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-3 text-amber-300 font-extrabold text-base">
            <Flame className="w-5 h-5 text-amber-400" />
            <span>MOD Features Info ({app.modFeatures.length})</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {app.modFeatures.map((feat, idx) => (
              <div key={idx} className="flex items-center gap-2 text-xs font-semibold text-slate-200 bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                <span>{feat}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Controls Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 overflow-x-auto pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'overview' ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Info className="w-4 h-4" />
          <span>Overview & Screenshots</span>
        </button>

        <button
          onClick={() => setActiveTab('install')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'install' ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          <span>Installation Guide</span>
        </button>

        <button
          onClick={() => setActiveTab('reviews')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'reviews' ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Reviews ({appReviews.length + app.reviewCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('faq')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
            activeTab === 'faq' ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/20' : 'text-slate-400 hover:text-white bg-slate-900'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>FAQ</span>
        </button>
      </div>

      {/* Tab Content Display */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Screenshots Gallery */}
            {app.screenshots && app.screenshots.length > 0 && (
              <div>
                <h3 className="text-base font-extrabold text-white mb-4 flex items-center gap-2">
                  <Maximize2 className="w-4 h-4 text-cyan-400" />
                  <span>Screenshots & Gameplay</span>
                </h3>
                <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
                  {app.screenshots.map((img, idx) => (
                    <div
                      key={idx}
                      onClick={() => setSelectedImage(img)}
                      className="shrink-0 w-64 sm:w-80 h-40 sm:h-48 rounded-2xl overflow-hidden border border-slate-700 cursor-pointer group relative snap-center"
                    >
                      <img
                        src={img}
                        alt={`Screenshot ${idx + 1}`}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Maximize2 className="w-6 h-6 text-white" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Description */}
            <div>
              <h3 className="text-base font-extrabold text-white mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>About {app.name}</span>
              </h3>
              <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                {app.description}
              </p>
            </div>

            {/* Changelog */}
            {app.changelog && app.changelog.length > 0 && (
              <div className="pt-4 border-t border-slate-800">
                <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <span>What's New in {app.version}</span>
                </h3>
                <ul className="space-y-2 text-xs text-slate-300">
                  {app.changelog.map((log, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                      <span>{log}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}

        {activeTab === 'install' && (
          <div className="space-y-6">
            <h3 className="text-base font-extrabold text-white">How to Install {app.name} APK</h3>
            <p className="text-xs text-slate-300">
              Follow these simple step-by-step instructions to manually install APK or MOD APK files on your Android device safely.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-cyan-400 font-bold flex items-center justify-center text-sm font-mono">
                  01
                </div>
                <h4 className="text-sm font-bold text-white">Download APK File</h4>
                <p className="text-xs text-slate-400">
                  Click the direct download button above to save the <strong>{app.name}</strong> file to your downloads folder.
                </p>
              </div>

              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-cyan-400 font-bold flex items-center justify-center text-sm font-mono">
                  02
                </div>
                <h4 className="text-sm font-bold text-white">Allow Unknown Sources</h4>
                <p className="text-xs text-slate-400">
                  Go to <strong>Settings &gt; Security &gt; Install Unknown Apps</strong> and grant permission to your browser or file manager.
                </p>
              </div>

              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-cyan-400 font-bold flex items-center justify-center text-sm font-mono">
                  03
                </div>
                <h4 className="text-sm font-bold text-white">Install APK File</h4>
                <p className="text-xs text-slate-400">
                  Open your Android File Manager, locate the downloaded <code>.apk</code> file, and tap <strong>Install</strong>.
                </p>
              </div>

              <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600/20 text-cyan-400 font-bold flex items-center justify-center text-sm font-mono">
                  04
                </div>
                <h4 className="text-sm font-bold text-white">Launch & Enjoy MOD</h4>
                <p className="text-xs text-slate-400">
                  Launch the app from your app drawer. All MOD features will automatically activate without needing root access!
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Rating Summary */}
              <div className="p-6 bg-slate-950/60 rounded-2xl border border-slate-800 text-center space-y-2">
                <p className="text-4xl font-black text-white">{app.rating.toFixed(1)}</p>
                <div className="flex items-center justify-center text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-slate-400">{app.reviewCount + appReviews.length} total user ratings</p>
              </div>

              {/* Submit Review Form */}
              <div className="md:col-span-2 p-6 bg-slate-950/60 rounded-2xl border border-slate-800">
                <h4 className="text-sm font-bold text-white mb-4">Leave a Review for {app.name}</h4>
                {reviewSubmitted ? (
                  <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Thank you! Your review has been submitted and posted instantly.</span>
                  </div>
                ) : (
                  <form onSubmit={handleReviewSubmit} className="space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-slate-400 uppercase">Your Name</label>
                        <input
                          type="text"
                          required
                          value={reviewerName}
                          onChange={(e) => setReviewerName(e.target.value)}
                          placeholder="e.g. Alex M."
                          className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-slate-400 uppercase">Rating</label>
                        <select
                          value={reviewRating}
                          onChange={(e) => setReviewRating(Number(e.target.value))}
                          className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                        >
                          <option value={5}>5 Stars - Outstanding MOD</option>
                          <option value={4}>4 Stars - Great App</option>
                          <option value={3}>3 Stars - Average</option>
                          <option value={2}>2 Stars - Needs Improvement</option>
                          <option value={1}>1 Star - Does Not Work</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-400 uppercase">Comment</label>
                      <textarea
                        required
                        rows={3}
                        value={reviewComment}
                        onChange={(e) => setReviewComment(e.target.value)}
                        placeholder="Share your experience with this MOD version..."
                        className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>

                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-xl transition-colors shadow-lg shadow-cyan-500/20"
                    >
                      Post Review
                    </button>
                  </form>
                )}
              </div>
            </div>

            {/* Reviews List */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h4 className="text-sm font-bold text-white">Recent Reviews</h4>
              {appReviews.length > 0 ? (
                appReviews.map((rev) => (
                  <div key={rev.id} className="p-4 bg-slate-950/40 rounded-2xl border border-slate-800 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center text-xs">
                          {rev.userName.charAt(0)}
                        </div>
                        <span className="text-xs font-bold text-white">{rev.userName}</span>
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
                          Verified Download
                        </span>
                      </div>
                      <div className="flex text-amber-400">
                        {[...Array(rev.rating)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-amber-400" />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-slate-300">{rev.comment}</p>
                    <span className="text-[10px] text-slate-500 font-mono">{rev.createdAt}</span>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-xs text-slate-400">
                  No custom reviews yet for this version. Be the first to post a review above!
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'faq' && (
          <div className="space-y-4">
            <h3 className="text-base font-extrabold text-white mb-2">Frequently Asked Questions</h3>
            {(app.faqs || [
              { question: `Is ${app.name} completely free and safe?`, answer: `Yes, KBMods tests all APK files with 65+ malware scanning engines including VirusTotal and Google Play Protect before publishing.` },
              { question: 'How do I update this MOD version in the future?', answer: 'Bookmark KBMods (kbmods.us.cc) and return whenever a new update is released. Simply install the updated APK over your existing version without deleting app data.' },
              { question: 'Will this ban my main social or gaming account?', answer: 'We build anti-ban shields into all our MOD releases, but for competitive games we always recommend using an alt account.' }
            ]).map((faq, i) => (
              <div key={i} className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-1.5">
                <h4 className="text-xs sm:text-sm font-bold text-cyan-300 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{faq.question}</span>
                </h4>
                <p className="text-xs text-slate-300 pl-6 leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Related Apps Grid */}
      {relatedApps.length > 0 && (
        <div className="pt-6">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400" />
            <span>More Apps You Might Like</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {relatedApps.map((relApp) => (
              <AppCard key={relApp.id} app={relApp} onSelect={onSelectApp} onQuickDownload={onOpenDownloadModal} />
            ))}
          </div>
        </div>
      )}

      {/* Screenshots Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-4xl w-full">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 p-2 bg-slate-800 text-white rounded-full hover:bg-slate-700"
            >
              <X className="w-6 h-6" />
            </button>
            <img src={selectedImage} alt="Expanded Screenshot" className="w-full max-h-[85vh] object-contain rounded-2xl" />
          </div>
        </div>
      )}
    </div>
  );
};
