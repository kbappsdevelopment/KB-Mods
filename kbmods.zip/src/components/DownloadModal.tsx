import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Download, CheckCircle2, AlertTriangle, FileCode2, Copy, Check, ExternalLink } from 'lucide-react';
import { AppItem } from '../types';

interface DownloadModalProps {
  app: AppItem | null;
  onClose: () => void;
  onDownloadStarted?: (app: AppItem) => void;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  app,
  onClose,
  onDownloadStarted,
}) => {
  const [countdown, setCountdown] = useState(5);
  const [isReady, setIsReady] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);

  useEffect(() => {
    if (!app) return;
    setCountdown(5);
    setIsReady(false);

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setIsReady(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [app]);

  if (!app) return null;

  const handleStartDownload = () => {
    if (onDownloadStarted) {
      onDownloadStarted(app);
    }
    // Trigger download preview anchor
    const link = document.createElement('a');
    link.href = app.downloadUrl;
    link.download = `${app.packageName}-${app.version}.apk`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const copySha256 = () => {
    const hash = app.sha256 || '9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b';
    navigator.clipboard.writeText(hash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-white my-8">
        {/* Header Bar */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="text-xs font-bold text-slate-300 font-mono">KBMods High-Speed Direct Mirror</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* App Info Box */}
          <div className="flex items-center gap-4 bg-slate-800/60 p-4 rounded-2xl border border-slate-700/60">
            <img
              src={app.iconUrl}
              alt={app.name}
              className="w-16 h-16 rounded-2xl object-cover bg-slate-950 border border-slate-700 shadow-md shrink-0"
            />
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase tracking-wider">
                {app.type}
              </span>
              <h3 className="text-base font-extrabold text-white truncate mt-1">{app.name}</h3>
              <p className="text-xs text-slate-400 truncate">
                {app.version} • {app.appSize} • {app.androidRequirement}
              </p>
            </div>
          </div>

          {/* Countdown Security Progress */}
          {!isReady ? (
            <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 text-center space-y-3">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-blue-600/20 border border-blue-500/40 text-cyan-400 text-xl font-black font-mono animate-pulse">
                {countdown}s
              </div>
              <h4 className="text-sm font-bold text-white">Generating Direct Secure Link...</h4>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Verifying package signatures & scanning file with 65 antivirus engines.
              </p>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-500 to-cyan-400 h-full transition-all duration-1000 ease-linear"
                  style={{ width: `${((5 - countdown) / 5) * 100}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="bg-emerald-950/30 border border-emerald-500/30 p-4 rounded-2xl text-center space-y-3">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Security Scan Passed — 0 Threats Found</span>
              </div>
              <p className="text-xs text-slate-300">Your direct mirror link is ready for immediate download.</p>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleStartDownload}
                  className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-black text-sm rounded-xl shadow-xl shadow-emerald-500/25 transition-all flex items-center justify-center gap-2 transform active:scale-95"
                >
                  <Download className="w-5 h-5" />
                  <span>Download APK ({app.appSize})</span>
                </button>

                <button
                  onClick={handleStartDownload}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Mirror Link #2 (Fast CDN Backup)</span>
                </button>
              </div>
            </div>
          )}

          {/* Package Details */}
          <div className="space-y-2 text-xs">
            <div className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 space-y-1.5 font-mono text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>Package:</span>
                <span className="text-slate-200">{app.packageName}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Developer:</span>
                <span className="text-slate-200">{app.developer}</span>
              </div>
              <div className="flex justify-between text-slate-400 items-center">
                <span>SHA-256 Checksum:</span>
                <button
                  onClick={copySha256}
                  className="text-cyan-400 hover:underline flex items-center gap-1 font-mono text-[10px]"
                >
                  {copiedHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
                </button>
              </div>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-2 text-amber-200 text-[11px]">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                <strong>Installation Tip:</strong> Enable "Install Unknown Apps" in your Android phone settings if prompted during installation.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
