import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  Search,
  Moon,
  Sun,
  Menu,
  X,
  Smartphone,
  Download,
  Flame,
  Grid,
  Lock,
  Sparkles,
  ChevronDown,
  User as UserIcon
} from 'lucide-react';
import { AppItem, Category } from '../types';
import { auth, onAuthStateChanged, User } from '../lib/firebase';

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  apps: AppItem[];
  categories: Category[];
  onSelectApp: (app: AppItem) => void;
  onSelectCategory: (categorySlug: string | null) => void;
  onOpenAdmin: () => void;
  onOpenSEOModal: () => void;
  currentView: string;
  setCurrentView: (view: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  darkMode,
  setDarkMode,
  apps,
  categories,
  onSelectApp,
  onSelectCategory,
  onOpenAdmin,
  onOpenSEOModal,
  currentView,
  setCurrentView,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!auth) return;
    const unsub = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsub();
  }, []);


  // Filter search results
  const searchResults = searchQuery.trim()
    ? apps.filter(
        (app) =>
          app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.developer.toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.modFeatures.some((f) => f.toLowerCase().includes(searchQuery.toLowerCase()))
      ).slice(0, 6)
    : [];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleAppClick = (app: AppItem) => {
    onSelectApp(app);
    setSearchQuery('');
    setIsSearchOpen(false);
    setIsMobileMenuOpen(false);
  };

  const handleCategoryClick = (slug: string | null) => {
    onSelectCategory(slug);
    setIsCategoryMenuOpen(false);
    setIsMobileMenuOpen(false);
    setCurrentView('home');
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-slate-900/90 dark:bg-slate-950/90 border-b border-slate-800 text-slate-100 transition-colors shadow-lg">
      {/* Top Banner Notice */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-500 text-white text-xs py-1 px-4 text-center font-medium flex items-center justify-center gap-2">
        <ShieldCheck className="w-3.5 h-3.5 text-cyan-200 animate-pulse" />
        <span>KBMods (kbmods.us.cc) - 100% Virus-Free Scanned MOD APKs & Premium Android Apps</span>
        <span className="hidden sm:inline-block bg-white/20 text-white px-2 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider">Verified</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div
          onClick={() => handleCategoryClick(null)}
          className="flex items-center gap-3 cursor-pointer group shrink-0"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 p-0.5 shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform duration-200">
            <div className="w-full h-full bg-slate-900 rounded-[10px] flex items-center justify-center">
              <Smartphone className="w-5 h-5 text-cyan-400 group-hover:rotate-12 transition-transform" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-xl font-black tracking-tight text-white font-mono">
                KB<span className="text-cyan-400">Mods</span>
              </span>
              <span className="bg-blue-500/20 text-cyan-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-cyan-500/30">
                PRO
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono tracking-wider">kbmods.us.cc</p>
          </div>
        </div>

        {/* Live Search Bar (Desktop) */}
        <div ref={searchRef} className="relative flex-1 max-w-md hidden md:block">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              onFocus={() => setIsSearchOpen(true)}
              placeholder="Search 10,000+ MOD APKs, Games, Tools..."
              className="w-full bg-slate-800/80 border border-slate-700/80 focus:border-cyan-400 rounded-full py-2 left-10 pl-10 pr-4 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Autocomplete Dropdown */}
          {isSearchOpen && searchQuery.trim().length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden z-50 divide-y divide-slate-800">
              {searchResults.length > 0 ? (
                <div>
                  <div className="px-4 py-2 bg-slate-950/50 text-[11px] font-semibold text-slate-400 tracking-wider uppercase flex justify-between">
                    <span>Search Results ({searchResults.length})</span>
                    <span>Press Enter for all</span>
                  </div>
                  {searchResults.map((app) => (
                    <div
                      key={app.id}
                      onClick={() => handleAppClick(app)}
                      className="p-3 hover:bg-slate-800/80 cursor-pointer flex items-center gap-3 transition-colors"
                    >
                      <img
                        src={app.iconUrl}
                        alt={app.name}
                        className="w-10 h-10 rounded-xl object-cover bg-slate-800 shrink-0 border border-slate-700"
                        loading="lazy"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-semibold text-white truncate">{app.name}</h4>
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              app.type === 'MOD'
                                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                                : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                            }`}
                          >
                            {app.type}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 truncate">
                          {app.version} • {app.category} • {app.appSize}
                        </p>
                      </div>
                      <Download className="w-4 h-4 text-cyan-400 shrink-0" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-6 text-center text-slate-400 text-sm">
                  No MOD apps found matching "<span className="text-white font-medium">{searchQuery}</span>". Try searching for "Subway", "Spotify", or "GTA".
                </div>
              )}
            </div>
          )}
        </div>

        {/* Navigation Menu (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1 text-sm font-medium text-slate-300">
          <button
            onClick={() => handleCategoryClick(null)}
            className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
              currentView === 'home' ? 'text-cyan-400 bg-slate-800' : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Flame className="w-4 h-4 text-amber-400" />
            <span>Home</span>
          </button>

          {/* Categories Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsCategoryMenuOpen(!isCategoryMenuOpen)}
              className="px-3 py-1.5 rounded-lg hover:text-white hover:bg-slate-800/60 transition-colors flex items-center gap-1"
            >
              <Grid className="w-4 h-4 text-cyan-400" />
              <span>Categories</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isCategoryMenuOpen ? 'rotate-180' : ''}`} />
            </button>

            {isCategoryMenuOpen && (
              <div className="absolute left-0 top-full mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 z-50 grid grid-cols-1 gap-1">
                <button
                  onClick={() => handleCategoryClick(null)}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs font-semibold text-cyan-400 hover:bg-slate-800 transition-colors flex items-center justify-between"
                >
                  <span>All Categories</span>
                  <span className="bg-cyan-500/20 text-cyan-300 px-2 py-0.5 rounded-full text-[10px]">12</span>
                </button>
                <div className="h-px bg-slate-800 my-1" />
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(cat.slug)}
                    className="w-full text-left px-3 py-1.5 rounded-lg text-xs text-slate-300 hover:text-white hover:bg-slate-800 transition-colors flex items-center justify-between"
                  >
                    <span>{cat.name}</span>
                    <span className="text-[10px] text-slate-500">{cat.appCount}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={onOpenSEOModal}
            className="px-3 py-1.5 rounded-lg hover:text-white hover:bg-slate-800/60 transition-colors flex items-center gap-1.5"
            title="Inspect Dynamic SEO, Open Graph & XML Sitemap"
          >
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>SEO Tools</span>
          </button>

          <button
            onClick={onOpenAdmin}
            className={`px-3 py-1.5 rounded-lg border transition-colors flex items-center gap-1.5 font-semibold text-xs ml-1 ${
              user
                ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300 hover:bg-cyan-500/30'
                : 'bg-blue-600/20 border-blue-500/40 text-blue-300 hover:bg-blue-600/30'
            }`}
          >
            {user?.photoURL ? (
              <img src={user.photoURL} alt="" className="w-4 h-4 rounded-full border border-cyan-400 shrink-0" />
            ) : user ? (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            ) : (
              <Lock className="w-3.5 h-3.5" />
            )}
            <span>{user ? user.displayName || user.email?.split('@')[0] || 'Admin' : 'Admin'}</span>
          </button>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white lg:hidden"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 py-4 space-y-3">
          {/* Mobile Search */}
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setIsSearchOpen(true);
              }}
              placeholder="Search apps or MOD games..."
              className="w-full bg-slate-800 border border-slate-700 rounded-xl py-2 pl-10 pr-4 text-sm text-white placeholder-slate-400 focus:outline-none"
            />
          </div>

          {searchQuery.trim().length > 0 && searchResults.length > 0 && (
            <div className="bg-slate-800/90 rounded-xl p-2 space-y-1 max-h-60 overflow-y-auto">
              {searchResults.map((app) => (
                <div
                  key={app.id}
                  onClick={() => handleAppClick(app)}
                  className="p-2 rounded-lg hover:bg-slate-700 flex items-center gap-3 cursor-pointer"
                >
                  <img src={app.iconUrl} alt={app.name} className="w-8 h-8 rounded-lg object-cover" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-white truncate">{app.name}</p>
                    <p className="text-[10px] text-slate-400">{app.version} • {app.category}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => handleCategoryClick(null)}
              className="p-2.5 rounded-xl bg-slate-800 text-left text-xs font-medium text-slate-200 flex items-center gap-2"
            >
              <Flame className="w-4 h-4 text-amber-400" />
              <span>All MOD Apps</span>
            </button>
            <button
              onClick={onOpenSEOModal}
              className="p-2.5 rounded-xl bg-slate-800 text-left text-xs font-medium text-purple-300 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>SEO Tools</span>
            </button>
          </div>

          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">Categories</p>
            <div className="grid grid-cols-2 gap-1.5 max-h-48 overflow-y-auto pr-1">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategoryClick(cat.slug)}
                  className="text-left px-3 py-1.5 bg-slate-800/60 hover:bg-slate-800 rounded-lg text-xs text-slate-300 truncate"
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => {
              setIsMobileMenuOpen(false);
              onOpenAdmin();
            }}
            className="w-full py-2.5 bg-blue-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30"
          >
            <Lock className="w-4 h-4" />
            <span>Admin Dashboard</span>
          </button>
        </div>
      )}
    </header>
  );
};
