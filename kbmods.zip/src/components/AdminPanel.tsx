import React, { useState, useEffect } from 'react';
import {
  X,
  Lock,
  Plus,
  Trash2,
  Edit3,
  BarChart3,
  Layers,
  CheckCircle2,
  AlertCircle,
  Download,
  Settings,
  MessageSquare,
  Save,
  Sparkles,
  User as UserIcon,
  LogOut,
  Mail,
  KeyRound,
  ShieldCheck,
  UserPlus,
  LogIn,
  Info
} from 'lucide-react';
import { AppItem, Category, Review, SEOMetadata, SiteStats } from '../types';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  signOut,
  onAuthStateChanged,
  User
} from '../lib/firebase';

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  apps: AppItem[];
  categories: Category[];
  reviews: Review[];
  seoData: SEOMetadata;
  stats: SiteStats;
  onAddApp: (app: AppItem) => void;
  onUpdateApp: (app: AppItem) => void;
  onDeleteApp: (id: string) => void;
  onAddCategory: (category: Category) => void;
  onDeleteCategory: (id: string) => void;
  onDeleteReview: (id: string) => void;
  onUpdateSEO: (newSEO: SEOMetadata) => void;
  onImportBackup: (importedData: { apps: AppItem[]; categories: Category[] }) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  isOpen,
  onClose,
  apps,
  categories,
  reviews,
  seoData,
  stats,
  onAddApp,
  onUpdateApp,
  onDeleteApp,
  onAddCategory,
  onDeleteCategory,
  onDeleteReview,
  onUpdateSEO,
  onImportBackup,
}) => {
  // Auth State
  const [user, setUser] = useState<User | null>(null);
  const [pinAuthenticated, setPinAuthenticated] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'pin'>('login');

  // Form Fields for Auth
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [isLoadingAuth, setIsLoadingAuth] = useState(false);

  // Active Admin Tab
  const [adminTab, setAdminTab] = useState<'analytics' | 'apps' | 'categories' | 'reviews' | 'seo' | 'backup'>('analytics');

  // App Form State (For Add / Edit)
  const [isAppModalOpen, setIsAppModalOpen] = useState(false);
  const [editingApp, setEditingApp] = useState<AppItem | null>(null);

  // Form Fields for Apps
  const [appName, setAppName] = useState('');
  const [packageName, setPackageName] = useState('');
  const [category, setCategory] = useState(categories[0]?.name || 'Action Games');
  const [version, setVersion] = useState('v1.0.0');
  const [appSize, setAppSize] = useState('100 MB');
  const [androidReq, setAndroidReq] = useState('Android 7.0+');
  const [developer, setDeveloper] = useState('');
  const [type, setType] = useState<'MOD' | 'Pure APK' | 'Premium Unlocked'>('MOD');
  const [modFeaturesStr, setModFeaturesStr] = useState('Unlimited Money, All Unlocked, No Ads');
  const [iconUrl, setIconUrl] = useState('');
  const [downloadUrl, setDownloadUrl] = useState('');
  const [description, setDescription] = useState('');
  const [changelogStr, setChangelogStr] = useState('Initial Release, Bug Fixes');
  const [isFeatured, setIsFeatured] = useState(false);
  const [isTrending, setIsTrending] = useState(false);

  // Category Form State
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');

  // SEO Edit State
  const [seoTitle, setSeoTitle] = useState(seoData.title);
  const [seoDesc, setSeoDesc] = useState(seoData.description);
  const [seoRobots, setSeoRobots] = useState(seoData.robotsTxt);

  // Listen to Auth State
  useEffect(() => {
    if (!auth) return;
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        setAuthError('');
      }
    });
    return () => unsubscribe();
  }, []);

  if (!isOpen) return null;

  const isAuthenticated = !!user || pinAuthenticated;

  // Google Login/Signup Handler
  const handleGoogleAuth = async () => {
    if (!auth) {
      setAuthError('Firebase Auth is not initialized properly.');
      return;
    }
    setIsLoadingAuth(true);
    setAuthError('');
    setAuthSuccess('');

    try {
      const result = await signInWithPopup(auth, googleProvider);
      setUser(result.user);
      setAuthSuccess(`Welcome Admin, ${result.user.displayName || result.user.email}!`);
    } catch (err: any) {
      console.error("Google Auth error:", err);
      if (err.code === 'auth/popup-closed-by-user') {
        setAuthError('Google Login popup was closed before completing.');
      } else if (err.code === 'auth/popup-blocked') {
        setAuthError('Pop-up was blocked by browser. Please allow popups or use Email/PIN Login.');
      } else {
        setAuthError(err.message || 'Failed to authenticate with Google.');
      }
    } finally {
      setIsLoadingAuth(false);
    }
  };

  // Email Login Handler
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth) {
      setAuthError('Firebase Auth is not initialized.');
      return;
    }
    if (!email || !password) {
      setAuthError('Please fill in both email and password.');
      return;
    }
    setIsLoadingAuth(true);
    setAuthError('');
    setAuthSuccess('');

    try {
      const res = await signInWithEmailAndPassword(auth, email, password);
      setUser(res.user);
      setAuthSuccess('Admin Login Successful!');
    } catch (err: any) {
      console.error("Email Login error:", err);
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        setAuthError('Invalid admin email or password.');
      } else if (err.code === 'auth/invalid-email') {
        setAuthError('Please enter a valid email address.');
      } else {
        setAuthError(err.message || 'Failed to login with Email & Password.');
      }
    } finally {
      setIsLoadingAuth(false);
    }
  };

  // Email Signup Handler
  const handleEmailSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth) {
      setAuthError('Firebase Auth is not initialized.');
      return;
    }
    if (!email || !password) {
      setAuthError('Please fill in email and password.');
      return;
    }
    if (password.length < 6) {
      setAuthError('Password must be at least 6 characters long.');
      return;
    }
    setIsLoadingAuth(true);
    setAuthError('');
    setAuthSuccess('');

    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      if (displayName.trim()) {
        await updateProfile(res.user, { displayName: displayName.trim() });
      }
      setUser({ ...res.user, displayName: displayName.trim() || res.user.email });
      setAuthSuccess('Admin Account Created & Authenticated Successfully!');
    } catch (err: any) {
      console.error("Email Signup error:", err);
      if (err.code === 'auth/email-already-in-use') {
        setAuthError('This email is already registered. Please switch to Login.');
      } else if (err.code === 'auth/weak-password') {
        setAuthError('Password should be at least 6 characters.');
      } else {
        setAuthError(err.message || 'Failed to create Admin account.');
      }
    } finally {
      setIsLoadingAuth(false);
    }
  };

  // Emergency PIN Login Handler
  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode === 'admin123' || passcode === 'admin') {
      setPinAuthenticated(true);
      setAuthError('');
      setAuthSuccess('Unlocked via Admin Passcode PIN.');
    } else {
      setAuthError('Invalid Admin PIN passcode. Default: admin123');
    }
  };

  // Logout Handler
  const handleLogout = async () => {
    if (auth) {
      await signOut(auth);
    }
    setUser(null);
    setPinAuthenticated(false);
    setAuthSuccess('');
    setAuthError('');
  };

  const openAddAppModal = () => {
    setEditingApp(null);
    setAppName('');
    setPackageName('');
    setCategory(categories[0]?.name || 'Action Games');
    setVersion('v1.0.0');
    setAppSize('120 MB');
    setAndroidReq('Android 7.0+');
    setDeveloper('KBMods Team');
    setType('MOD');
    setModFeaturesStr('Unlimited Money\nAll Levels Unlocked\nNo Ads');
    setIconUrl('https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=256&q=80');
    setDownloadUrl('https://kbmods.us.cc/downloads/new-app-kbmods.apk');
    setDescription('Comprehensive MOD description with premium unlocked features.');
    setChangelogStr('Updated base code\nFixed compatibility for Android 15');
    setIsFeatured(true);
    setIsTrending(true);
    setIsAppModalOpen(true);
  };

  const openEditAppModal = (appItem: AppItem) => {
    setEditingApp(appItem);
    setAppName(appItem.name);
    setPackageName(appItem.packageName);
    setCategory(appItem.category);
    setVersion(appItem.version);
    setAppSize(appItem.appSize);
    setAndroidReq(appItem.androidRequirement);
    setDeveloper(appItem.developer);
    setType(appItem.type);
    setModFeaturesStr(appItem.modFeatures.join('\n'));
    setIconUrl(appItem.iconUrl);
    setDownloadUrl(appItem.downloadUrl);
    setDescription(appItem.description);
    setChangelogStr(appItem.changelog.join('\n'));
    setIsFeatured(!!appItem.isFeatured);
    setIsTrending(!!appItem.isTrending);
    setIsAppModalOpen(true);
  };

  const handleSaveApp = (e: React.FormEvent) => {
    e.preventDefault();
    const appData: AppItem = {
      id: editingApp ? editingApp.id : `app-${Date.now()}`,
      name: appName,
      packageName,
      category,
      version,
      appSize,
      androidRequirement: androidReq,
      developer,
      lastUpdated: new Date().toISOString().split('T')[0],
      type,
      modFeatures: modFeaturesStr.split('\n').map((s) => s.trim()).filter(Boolean),
      iconUrl: iconUrl || 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=256&q=80',
      screenshots: editingApp?.screenshots || [
        'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80'
      ],
      description,
      changelog: changelogStr.split('\n').map((s) => s.trim()).filter(Boolean),
      downloadUrl: downloadUrl || 'https://kbmods.us.cc/downloads/sample.apk',
      fileSizeMb: parseInt(appSize) || 120,
      rating: editingApp ? editingApp.rating : 4.9,
      reviewCount: editingApp ? editingApp.reviewCount : 1,
      downloadCount: editingApp ? editingApp.downloadCount : 100,
      isFeatured,
      isTrending,
      sha256: editingApp?.sha256 || 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0',
    };

    if (editingApp) {
      onUpdateApp(appData);
    } else {
      onAddApp(appData);
    }
    setIsAppModalOpen(false);
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    const slug = newCatName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const newCat: Category = {
      id: `cat-${Date.now()}`,
      name: newCatName.trim(),
      slug,
      iconName: 'Grid',
      description: newCatDesc || 'Custom category for Android apps',
      appCount: 0,
      color: 'from-blue-600 to-indigo-700'
    };
    onAddCategory(newCat);
    setNewCatName('');
    setNewCatDesc('');
  };

  const handleExportJSON = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify({ apps, categories, seoData }, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `kbmods-backup-${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.apps && Array.isArray(json.apps)) {
          onImportBackup({ apps: json.apps, categories: json.categories || categories });
          alert('Backup restored successfully!');
        }
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-white my-6">
        {/* Top Bar Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600/20 text-blue-400 rounded-xl border border-blue-500/30">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>KBMods Administrative Control Panel</span>
                <span className="text-[10px] bg-cyan-500/20 text-cyan-300 font-mono px-2 py-0.5 rounded border border-cyan-500/30">
                  v2.5
                </span>
              </h2>
              <p className="text-[10px] text-slate-400 font-mono">kbmods.us.cc — Admin Portal</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && (
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-xl">
                {user?.photoURL ? (
                  <img src={user.photoURL} alt="" className="w-6 h-6 rounded-full border border-cyan-400" />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-black text-xs flex items-center justify-center">
                    {(user?.displayName || user?.email || 'A').charAt(0).toUpperCase()}
                  </div>
                )}
                <span className="text-xs font-bold text-white hidden sm:inline-block max-w-[120px] truncate">
                  {user?.displayName || user?.email || 'Admin User'}
                </span>
                <button
                  onClick={handleLogout}
                  className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                  title="Logout Admin"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}

            <button
              onClick={onClose}
              className="p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Authentication Form Card (If Not Authenticated) */}
        {!isAuthenticated ? (
          <div className="p-6 sm:p-10 max-w-lg mx-auto text-center space-y-6">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-blue-600 to-cyan-400 text-slate-950 flex items-center justify-center mx-auto shadow-xl shadow-cyan-500/20">
              <Lock className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-2xl font-black text-white">Admin Portal Sign In</h3>
              <p className="text-xs text-slate-400 mt-1">
                Google Login, Email & Password Sign Up, or Admin Passcode PIN
              </p>
            </div>

            {/* Auth Mode Switcher Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setAuthError('');
                }}
                className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'login' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Email Login</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthMode('signup');
                  setAuthError('');
                }}
                className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'signup' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Email Sign Up</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthMode('pin');
                  setAuthError('');
                }}
                className={`py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                  authMode === 'pin' ? 'bg-cyan-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>PIN Code</span>
              </button>
            </div>

            {/* Google Quick Login Button (Prominent) */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={handleGoogleAuth}
                disabled={isLoadingAuth}
                className="w-full py-3 bg-white hover:bg-slate-100 text-slate-900 font-extrabold text-xs rounded-2xl shadow-lg transition-all flex items-center justify-center gap-3 border border-slate-200"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.29v3.15C3.26 21.3 7.31 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.29C.47 8.21 0 10.05 0 12s.47 3.79 1.29 5.42l3.99-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.58l3.99 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Continue with Google Account</span>
              </button>

              <div className="flex items-center gap-3 text-slate-500 text-xs my-2">
                <div className="h-px bg-slate-800 flex-1" />
                <span>OR</span>
                <div className="h-px bg-slate-800 flex-1" />
              </div>
            </div>

            {/* Dynamic Form based on Auth Mode */}
            {authMode === 'login' && (
              <form onSubmit={handleEmailLogin} className="space-y-3 text-left">
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1">
                    <Mail className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Admin Email Address</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@kbmods.us.cc"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1">
                    <Lock className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Password</span>
                  </label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoadingAuth}
                  className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 font-extrabold text-xs text-white rounded-xl shadow-lg transition-all"
                >
                  {isLoadingAuth ? 'Authenticating...' : 'Sign In as Admin'}
                </button>
              </form>
            )}

            {authMode === 'signup' && (
              <form onSubmit={handleEmailSignup} className="space-y-3 text-left">
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1">
                    <UserIcon className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Admin Display Name</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. KBMods Admin"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1">
                    <Mail className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Email Address</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@kbmods.us.cc"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1">
                    <Lock className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Create Password (Min 6 chars)</span>
                  </label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoadingAuth}
                  className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-extrabold text-xs text-slate-950 rounded-xl shadow-lg transition-all"
                >
                  {isLoadingAuth ? 'Creating Account...' : 'Register New Admin Account'}
                </button>
              </form>
            )}

            {authMode === 'pin' && (
              <form onSubmit={handlePinLogin} className="space-y-3 text-left">
                <div>
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-1">
                    <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Admin PIN Passcode</span>
                  </label>
                  <input
                    type="password"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    placeholder="Enter PIN (Default: admin123)..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-center text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-slate-800 hover:bg-slate-700 font-extrabold text-xs text-white rounded-xl shadow-lg transition-all border border-slate-700"
                >
                  Unlock Admin Panel
                </button>
              </form>
            )}

            {/* Error / Success feedback */}
            {authError && (
              <div className="p-3 bg-rose-950/60 border border-rose-500/40 rounded-xl text-rose-300 text-xs flex items-center gap-2 text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{authError}</span>
              </div>
            )}

            {authSuccess && (
              <div className="p-3 bg-emerald-950/60 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2 text-left">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{authSuccess}</span>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col md:flex-row h-[75vh]">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-60 bg-slate-950 border-r border-slate-800 p-4 space-y-1 shrink-0 flex flex-col justify-between">
              <div className="space-y-1">
                <button
                  onClick={() => setAdminTab('analytics')}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                    adminTab === 'analytics' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  <span>Analytics Overview</span>
                </button>

                <button
                  onClick={() => setAdminTab('apps')}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${
                    adminTab === 'apps' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Layers className="w-4 h-4" />
                    <span>Manage Apps ({apps.length})</span>
                  </div>
                </button>

                <button
                  onClick={() => setAdminTab('categories')}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                    adminTab === 'categories' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <Settings className="w-4 h-4" />
                  <span>Categories ({categories.length})</span>
                </button>

                <button
                  onClick={() => setAdminTab('reviews')}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-between ${
                    adminTab === 'reviews' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <MessageSquare className="w-4 h-4" />
                    <span>User Reviews</span>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded-full">{reviews.length}</span>
                </button>

                <button
                  onClick={() => setAdminTab('seo')}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                    adminTab === 'seo' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>SEO Settings</span>
                </button>

                <button
                  onClick={() => setAdminTab('backup')}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2.5 ${
                    adminTab === 'backup' ? 'bg-cyan-500 text-slate-950 shadow-md' : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                  }`}
                >
                  <Download className="w-4 h-4" />
                  <span>Backup & Restore</span>
                </button>
              </div>

              {/* Admin Profile Details at Sidebar Bottom */}
              <div className="pt-4 border-t border-slate-800 space-y-2">
                <div className="bg-slate-900 p-2.5 rounded-2xl border border-slate-800 text-xs space-y-1">
                  <div className="flex items-center gap-2">
                    {user?.photoURL ? (
                      <img src={user.photoURL} alt="" className="w-7 h-7 rounded-full border border-cyan-400 shrink-0" />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-cyan-500 text-slate-950 font-extrabold flex items-center justify-center shrink-0">
                        {(user?.displayName || user?.email || 'A').charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-white truncate text-[11px]">
                        {user?.displayName || 'Admin'}
                      </p>
                      <p className="text-[10px] text-slate-400 truncate">
                        {user?.email || 'PIN Authenticated'}
                      </p>
                    </div>
                  </div>
                  <div className="pt-1 flex items-center justify-between text-[10px] text-emerald-400 font-mono">
                    <span className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                      Active Session
                    </span>
                    <button
                      onClick={handleLogout}
                      className="text-rose-400 hover:underline font-sans font-bold"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Admin Content View */}
            <div className="flex-1 p-6 overflow-y-auto bg-slate-900">
              {adminTab === 'analytics' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-bold text-white">System Analytics & Directory Performance</h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total MOD Apps</p>
                      <p className="text-2xl font-black text-white">{apps.length}</p>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Downloads</p>
                      <p className="text-2xl font-black text-cyan-400">
                        {(apps.reduce((acc, a) => acc + a.downloadCount, 0) / 1000000).toFixed(1)}M
                      </p>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Daily Visitors</p>
                      <p className="text-2xl font-black text-emerald-400">14,250</p>
                    </div>

                    <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Server Status</p>
                      <p className="text-2xl font-black text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        <span>Online</span>
                      </p>
                    </div>
                  </div>

                  {/* System Log */}
                  <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-2">
                    <h4 className="text-xs font-bold text-slate-300">Firebase & CDN Storage Health</h4>
                    <p className="text-xs text-slate-400 font-mono">
                      Connected to Firestore project: <strong className="text-cyan-400">kb-nova-kashyap</strong>
                    </p>
                    <p className="text-xs text-slate-400 font-mono">
                      Authenticated Admin UID: <strong className="text-cyan-400">{user?.uid || 'local-admin-pin'}</strong>
                    </p>
                    <p className="text-xs text-slate-400 font-mono">
                      Domain Route: <strong className="text-cyan-400">kbmods.us.cc</strong>
                    </p>
                  </div>
                </div>
              )}

              {adminTab === 'apps' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-white">App Listings Management</h3>
                    <button
                      onClick={openAddAppModal}
                      className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 shadow-lg shadow-cyan-500/20"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add New App</span>
                    </button>
                  </div>

                  <div className="divide-y divide-slate-800 bg-slate-950/60 rounded-2xl border border-slate-800 overflow-hidden">
                    {apps.map((appItem) => (
                      <div key={appItem.id} className="p-3 hover:bg-slate-900 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <img src={appItem.iconUrl} alt="" className="w-10 h-10 rounded-xl object-cover bg-slate-900 shrink-0" />
                          <div className="min-w-0">
                            <h4 className="text-xs font-bold text-white truncate">{appItem.name}</h4>
                            <p className="text-[10px] text-slate-400 truncate">
                              {appItem.packageName} • {appItem.version} • {appItem.category}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => openEditAppModal(appItem)}
                            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-lg text-xs"
                            title="Edit App"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => onDeleteApp(appItem.id)}
                            className="p-1.5 bg-slate-800 hover:bg-rose-900/50 text-rose-400 rounded-lg text-xs"
                            title="Delete App"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {adminTab === 'categories' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-bold text-white">Categories System Manager</h3>

                  {/* Add New Category */}
                  <form onSubmit={handleCreateCategory} className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-3">
                    <h4 className="text-xs font-bold text-white">Add Custom Category</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        placeholder="Category Name (e.g. Strategy Mods)..."
                        className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                      />
                      <input
                        type="text"
                        value={newCatDesc}
                        onChange={(e) => setNewCatDesc(e.target.value)}
                        placeholder="Brief description..."
                        className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl"
                    >
                      Create Category
                    </button>
                  </form>

                  {/* List Categories */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {categories.map((c) => (
                      <div key={c.id} className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 flex items-center justify-between">
                        <div>
                          <p className="text-xs font-bold text-white">{c.name}</p>
                          <p className="text-[10px] text-slate-400">{c.slug}</p>
                        </div>
                        <button
                          onClick={() => onDeleteCategory(c.id)}
                          className="p-1 text-rose-400 hover:bg-rose-900/40 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {adminTab === 'reviews' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white">User Reviews Moderation</h3>
                  <div className="space-y-2">
                    {reviews.map((r) => (
                      <div key={r.id} className="p-3 bg-slate-950/60 rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white">{r.userName}</span>
                            <span className="text-amber-400 font-bold">★ {r.rating}</span>
                          </div>
                          <p className="text-slate-300 mt-1">{r.comment}</p>
                        </div>
                        <button
                          onClick={() => onDeleteReview(r.id)}
                          className="p-1.5 bg-rose-900/30 text-rose-400 rounded-lg hover:bg-rose-900/50 shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {adminTab === 'seo' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-white">Dynamic SEO Metadata & Settings</h3>
                  <div className="space-y-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800 text-xs">
                    <div>
                      <label className="font-bold text-slate-300">Meta Title</label>
                      <input
                        type="text"
                        value={seoTitle}
                        onChange={(e) => setSeoTitle(e.target.value)}
                        className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white"
                      />
                    </div>

                    <div>
                      <label className="font-bold text-slate-300">Meta Description</label>
                      <textarea
                        rows={2}
                        value={seoDesc}
                        onChange={(e) => setSeoDesc(e.target.value)}
                        className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white"
                      />
                    </div>

                    <div>
                      <label className="font-bold text-slate-300">Robots.txt Content</label>
                      <textarea
                        rows={4}
                        value={seoRobots}
                        onChange={(e) => setSeoRobots(e.target.value)}
                        className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-[11px]"
                      />
                    </div>

                    <button
                      onClick={() => onUpdateSEO({ ...seoData, title: seoTitle, description: seoDesc, robotsTxt: seoRobots })}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl flex items-center gap-1.5"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save SEO Settings</span>
                    </button>
                  </div>
                </div>
              )}

              {adminTab === 'backup' && (
                <div className="space-y-6">
                  <h3 className="text-lg font-bold text-white">Database Backup & Restore</h3>

                  <div className="p-6 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-4">
                    <h4 className="text-sm font-bold text-white">Export Directory Backup</h4>
                    <p className="text-xs text-slate-400">
                      Download a complete JSON file containing all MOD apps, categories, and site settings.
                    </p>
                    <button
                      onClick={handleExportJSON}
                      className="px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      <span>Export Database JSON</span>
                    </button>
                  </div>

                  <div className="p-6 bg-slate-950/60 rounded-2xl border border-slate-800 space-y-4">
                    <h4 className="text-sm font-bold text-white">Restore From Backup</h4>
                    <p className="text-xs text-slate-400">
                      Upload a previously saved `.json` file to restore directory apps.
                    </p>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleImportFile}
                      className="text-xs text-slate-300 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-cyan-400 hover:file:bg-slate-700"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Add / Edit App Modal */}
      {isAppModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-2xl text-white my-8 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">
                {editingApp ? 'Edit App Listing' : 'Add New MOD APK Listing'}
              </h3>
              <button onClick={() => setIsAppModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveApp} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-400">App Name</label>
                  <input
                    type="text"
                    required
                    value={appName}
                    onChange={(e) => setAppName(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-400">Package Name</label>
                  <input
                    type="text"
                    required
                    value={packageName}
                    onChange={(e) => setPackageName(e.target.value)}
                    placeholder="com.example.app"
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-400">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-400">Version</label>
                  <input
                    type="text"
                    value={version}
                    onChange={(e) => setVersion(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-400">Type</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  >
                    <option value="MOD">MOD APK</option>
                    <option value="Pure APK">Pure APK</option>
                    <option value="Premium Unlocked">Premium Unlocked</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-400">App Size</label>
                  <input
                    type="text"
                    value={appSize}
                    onChange={(e) => setAppSize(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-400">Developer</label>
                  <input
                    type="text"
                    value={developer}
                    onChange={(e) => setDeveloper(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-400">Android Req.</label>
                  <input
                    type="text"
                    value={androidReq}
                    onChange={(e) => setAndroidReq(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-400">MOD Features (One per line)</label>
                <textarea
                  rows={2}
                  value={modFeaturesStr}
                  onChange={(e) => setModFeaturesStr(e.target.value)}
                  className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-400">Icon URL</label>
                  <input
                    type="text"
                    value={iconUrl}
                    onChange={(e) => setIconUrl(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-400">Download APK URL</label>
                  <input
                    type="text"
                    value={downloadUrl}
                    onChange={(e) => setDownloadUrl(e.target.value)}
                    className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-400">Description</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full mt-1 bg-slate-950 border border-slate-700 rounded-xl p-2 text-white"
                />
              </div>

              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-700 text-cyan-400"
                  />
                  <span>Featured App</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isTrending}
                    onChange={(e) => setIsTrending(e.target.checked)}
                    className="rounded bg-slate-950 border-slate-700 text-cyan-400"
                  />
                  <span>Trending App</span>
                </label>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAppModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl"
                >
                  Save App Listing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
